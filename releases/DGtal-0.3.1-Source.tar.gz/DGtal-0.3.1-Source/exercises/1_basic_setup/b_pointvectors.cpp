#include <stdio.h>
#include <iostream>

#include <DGtal/base/Common.h>


int main(int argc, char **argv)
{

  /**
   * Create two vectors of "double" in a 6D space.
   */


  /**
   * Init these two vectors with random values.
   */


  /**
   * Compute the sum of them to a third vector,.
   */


  /**
   * Compute the maximum value of the sum.
   */
  

  /**
   * Display the vector values to the standart output.
   */
  

  return 0;
}
