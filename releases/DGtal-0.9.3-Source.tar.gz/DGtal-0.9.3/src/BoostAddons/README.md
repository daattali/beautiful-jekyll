#Boost Add-ons

This folder contains some Boost add-ons that must be complied into the main
DGtal library.

  - [zlib.cpp](zlib.cpp) Zlib wrapper for boost iostream zlib filter (http://www.boost.org/doc/libs/1_50_0/libs/iostreams/doc/classes/zlib.html)
