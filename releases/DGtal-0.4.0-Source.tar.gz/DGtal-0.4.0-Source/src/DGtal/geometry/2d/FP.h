/**
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 **/

#pragma once

/**
 * @file FP.h
 * @author Tristan Roussillon (\c tristan.roussillon@liris.cnrs.fr )
 * Laboratoire d'InfoRmatique en Image et Systèmes d'information - LIRIS (CNRS, UMR 5205), CNRS, France
 *
 * @date 2011/01/26
 *
 * @brief Header file for module FP.cpp
 *
 * This file is part of the DGtal library.
 */

#if defined(FP_RECURSES)
#error Recursive header files inclusion detected in FP.h
#else // defined(FP_RECURSES)
/** Prevents recursive inclusion of headers. */
#define FP_RECURSES

#if !defined FP_h
/** Prevents repeated inclusion of headers. */
#define FP_h

//////////////////////////////////////////////////////////////////////////////
// Inclusions
#include <iostream>
#include <list>
#include "DGtal/kernel/CInteger.h"
#include "DGtal/kernel/PointVector.h"
#include "DGtal/geometry/2d/ArithmeticalDSS.h"
#include "DGtal/base/Circulator.h"
#include "DGtal/base/Exceptions.h"
#include "DGtal/base/Common.h"
#include "DGtal/io/Color.h"
//////////////////////////////////////////////////////////////////////////////

namespace DGtal
{

  /////////////////////////////////////////////////////////////////////////////
  /**
   * \brief Aim: abstract adapter for ArithmeticalDSS.
   * Has 2 virtual methods: 
   * - firstLeaningPoint()
   * - lastLeaningPoint()
   *
   * @see Adapter4ConvexPart Adapter4ConcavePart
   * 
   * @tparam 'ArithmeticalDSS'  type for arithmetical recognition algorithm of DSS. 
   * Must have a nested type Point and have four accessors: 
   *  getUf(), getUl(), getLf(), getLl()
   *
   */
   template <typename ArithmeticalDSS>
  class Adapter 
  {
    protected:
      /**
       *  A pointer to an instance of ArithmeticalDSS
       */
      ArithmeticalDSS* myDSS;
    public:
      /**
       *  @return the first upper or lower leaning point
       */
      virtual typename ArithmeticalDSS::Point firstLeaningPoint() const = 0;
      /**
       *  @return the last upper or lower leaning point
       */
      virtual typename ArithmeticalDSS::Point lastLeaningPoint() const = 0;
  };

  /**
   * \brief Aim: adapter for ArithmeticalDSS used by FP in convex parts.
   * Has 2 methods: 
   * - firstLeaningPoint()
   * - lastLeaningPoint()
   *
   * that respectively return the first and last upper leaning point 
   * of the underlying instance of ArithmeticalDSS. 
   * 
   * @tparam 'ArithmeticalDSS'  type for arithmetical recognition algorithm of DSS. 
   * Must have a nested type Point and have four accessors: 
   *  getUf(), getUl(), getLf(), getLl()
   *
   * @see Adapter FP
   */
  template <typename ArithmeticalDSS>
  class Adapter4ConvexPart : public Adapter<ArithmeticalDSS> 
  {
    public:
      /**
       *  Constructor
       * @param aDSS
       */
      Adapter4ConvexPart(ArithmeticalDSS& aDSS)
      {
        this->myDSS = &aDSS;
      }
      /**
       *  @return the first upper leaning point
       */
      virtual typename ArithmeticalDSS::Point firstLeaningPoint() const 
      {
        return this->myDSS->getUf();
      }
      /**
       *  @return the last upper leaning point
       */
      virtual typename ArithmeticalDSS::Point lastLeaningPoint() const
      {
        return this->myDSS->getUl();
      }
  };

  /**
   * \brief Aim: adapter for ArithmeticalDSS used by FP in concave parts.
   * Has 2 methods: 
   * - firstLeaningPoint()
   * - lastLeaningPoint()
   *
   * that respectively return the first and last lower leaning point 
   * of the underlying instance of ArithmeticalDSS. 
   * 
   * @tparam 'ArithmeticalDSS'  type for arithmetical recognition algorithm of DSS. 
   * Must have a nested type Point and have four accessors: 
   *  getUf(), getUl(), getLf(), getLl()
   *
   * @see Adapter FP
   */
  template <typename ArithmeticalDSS>
  class Adapter4ConcavePart : public Adapter<ArithmeticalDSS> 
  {
    public:
      /**
       *  Constructor
       * @param aDSS
       */
      Adapter4ConcavePart(ArithmeticalDSS& aDSS)
      {
        this->myDSS = &aDSS;
      }
      /**
       *  @return the first lower leaning point
       */
      virtual typename ArithmeticalDSS::Point firstLeaningPoint() const 
      {
        return this->myDSS->getLf();
      }
      /**
       *  @return the last lower leaning point
       */
      virtual typename ArithmeticalDSS::Point lastLeaningPoint() const
      {
        return this->myDSS->getLl();
      }
  };
  /////////////////////////////////////////////////////////////////////////////


  /////////////////////////////////////////////////////////////////////////////
  // template class FP
  /**
   * \brief Aim: Computes the faithful polygon (FP)
   * of a range of 4/8-connected 2D Points. 
   * 
   * The FP has several interesting properties: 
   *  - its vertices are points of the underlying digital curve, thus with integer coordinates, 
   *  - it respects the convex and concave parts of the underlying digital curve,
   *  - it is reversible, 
   *  - it is unique for digital curves that are not digital straight segments,
   *  - it is closed to the minimum length polygon (MLP) (and converges toward the MLP
   * as the resolution tends to the infinity) for closed digital curves.  
   *
   * It is computed in the course of the maximal digital straight segments computation,
   * because in convex parts (resp. concave parts), the first and last upper (resp. lower) 
   * leaning points of segments that are maximal at the front or at the back are also
   * vertices of the FP.
   * 
   * @see ArithmeticalDSS Adapter Adapter4ConvexPart Adapter4ConcavePart
   *
   * @note T. ROUSSILLON and I. SIVIGNON, 
   * Faithful polygonal representation of the convex and concave parts of a digital curve, 
   * Pattern Recognition, Volume 44, Issues 10-11, October-November 2011, Pages 2693-2700. 
   *
   * Usage:
   * @code
   //r is a range of 4-connected 2D points
   FP<ConstIterator, Integer, 4> theFP( r .begin(), r.end() );
   * @endcode
   *
   * Once the FP is computed, copyFP() is a way of geting its vertices. 
   * In the same way, copyMLP() is a way of getting the vertices of the MLP. 
   * 
   * @tparam 'TIterator'  type ConstIterator on 2D points, 
   * @tparam 'TInteger'  type of scalars used for the DSS parameters 
   * (satisfying CInteger) 
   * @tparam 'connectivity'  an integer equal to 
   * 4 for standard (4-connected) DSS or 8 for naive (8-connected) DSS. 
   * (Any other integers act as 8). 
   *
   * @see testFP.cpp
   */
  template <typename TIterator, typename TInteger, int connectivity>
  class FP
  {

    // ----------------------- Types ------------------------------
  public:


    BOOST_CONCEPT_ASSERT(( CInteger<TInteger> ) );
    
    typedef DGtal::PointVector<2,TInteger> Point;
    typedef DGtal::PointVector<2,TInteger> Vector;
    
    typedef DGtal::PointVector<2, double> RealPoint;
    typedef DGtal::PointVector<2, double> RealVector;
    
    typedef DGtal::ArithmeticalDSS<TIterator,TInteger,connectivity> DSSComputer;
    typedef DGtal::ArithmeticalDSS<DGtal::Circulator<TIterator>,TInteger,connectivity> DSSComputerInLoop;
    
    typedef std::list<Point> Polygon;
    


    // ----------------------- Standard services ------------------------------
  public:

    /**
     * Constructor.
     * @param itb  begin iterator
     * @param ite  end iterator
     */
    FP(const TIterator& itb, const TIterator& ite) throw( InputException ) ;
  
    /**
     * Constructor.
     * @param itb  begin iterator
     * @param ite  end iterator
     * @param isClosed 'true' if the range has to be considered as circular, 
     * 'false' otherwise. 
     */
    FP(const TIterator& itb, const TIterator& ite, const bool& isClosed) throw( InputException ) ;

    /**
     * Destructor.
     */
    ~FP();

    // ----------------------- Interface --------------------------------------
  public:



    /**
     * Checks the validity/consistency of the object.
     * @return 'true' if the object is valid, 'false' otherwise.
     */
    bool isValid() const;

    /**
     * @return number of FP vertices
     */
    typename Polygon::size_type size() const;


    /**
     * @return the vertices of the FP
     * NB: O(n)
     */
    template <typename OutputIterator>
    OutputIterator copyFP(OutputIterator result) const; 

    /**
     * @return the vertices of the MLP
     * NB: O(n)
     */
    template <typename OutputIterator>
    OutputIterator copyMLP(OutputIterator result) const; 


    // ------------------------- Protected Datas ------------------------------
  private:
    // ------------------------- Private Datas --------------------------------
  private:

    /*
    * list where each vertex of the FP is stored
    */
    Polygon myPolygon; 

    /*
    * bool equal to 'true' if the list has to be consider as circular
    * 'false' otherwise
    */
    bool myFlagIsClosed;

    // ------------------------- Hidden services ------------------------------
  protected:



  private:

    /**
     * A DSS adapter is chosen according to the local convexity/concavity
     * @param aDSS a DSS lying on the range to process
     * @param anAdapter an Adapter to @a aDSS for convex part
     * when 'true' is returned, for concave part otherwise
     * @param i an iterator pointing after the front of @a aDSS 
     * @return 'true' if @a aDSS begins a convex part, 'false' otherwise
     */
    template<typename DSS, typename Adapter>
    bool initConvexityConcavity( DSS &aDSS,  
                                 Adapter* &anAdapter,
                                 const typename DSS::ConstIterator& i );

    /**
     * Main algorithm
     * @param currentDSS a DSS lying on the range to process
     * @param adapter an Adapter to @a currentDSS
     * @param isConvex, 'true' if @a currentDSS is in a convex part, 'false' otherwise
     * @param i an iterator pointing after the front of @a currentDSS 
     * @param end iterator used to stop the algorithm (when @a i == @a end )
     */
    template<typename DSS, typename Adapter>
    void mainAlgorithm( DSS &currentDSS, Adapter* adapter, 
                        bool isConvex, 
                        typename DSS::ConstIterator i, 
                        const typename DSS::ConstIterator& end )  throw( InputException ) ;


    /**
     * Gets a MLP vertex from three consecutive vertices of the FP.
     * @param a previous vertex of the FP
     * @param b current vertex of the FP
     * @param c next vertex of the FP
     * @return vertex of the MLP, which is 
     * the tranlated of @a b by (+- 0.5, +- 0.5)
     */
    RealPoint getRealPoint (const Point& a,const Point& b, const Point& c) const;

    /**
     * Returns the quadrant number of a vector
     * @param v any ector
     * @param q a quandrant number (0,1,2 or 3)
     * @return 'true' if @a v lies in quadrant number @a q, 'false' otherwise
     */

    bool quadrant (const Vector& v, const int& q) const;

    /**
     * Copy constructor.
     * @param other the object to clone.
     * Forbidden by default.
     */
    FP ( const FP & other );

    /**
     * Assignment.
     * @param other the object to copy.
     * @return a reference on 'this'.
     * Forbidden by default.
     */
    FP & operator= ( const FP & other );

    // ------------------------- Display ------------------------------------
  public: 


    /**
     * Default style.
     */
    struct DefaultDrawStyle : public DrawableWithBoard2D
    {
        /**
         * Drawing method.
         * @param board the output board where the object is drawn.
         */
        virtual void selfDraw(Board2D & aBoard) const
        {
        // Set board style
        aBoard.setLineStyle(Board2D::Shape::SolidStyle);
        aBoard.setPenColor(Color::Red);
        aBoard.setLineWidth(2);
        aBoard.setFillColor(Color::None);
        }
    };

    /*
     * Writes/Displays the object on an output stream.
     * @param out the output stream where the object is written.
     */
    void selfDisplay ( std::ostream & out ) const;
    
    
    // --------------- CDrawableWithBoard2D realization --------------------
  public:
    
    /**
     * Default drawing style object.
     * @param mode the drawing mode.
     * @return the dyn. alloc. default style for this object.
     */
    DrawableWithBoard2D* defaultStyle( std::string mode = "" ) const;
    
    /**
     * @return the style name used for drawing this object.
     */
    std::string styleName() const;

    /**
     * Draw the vertices of the FP as a polygonal line 
     * @param board the output board where the object is drawn.
     *
     */
    void selfDraw(Board2D & board ) const;


    /**
     * Draw the FP on a board
     * @param board the output board where the object is drawn.
     */
    void selfDrawAsPolygon( Board2D & board ) const;



  }; // end of class FP


  /**
   * Overloads 'operator<<' for displaying objects of class 'FP'.
   * @param out the output stream where the object is written.
   * @param object the object of class 'FP' to write.
   * @return the output stream after the writing.
   */
  template <typename TIterator, typename TInteger, int connectivity>
  std::ostream&
  operator<< ( std::ostream & out, const FP<TIterator,TInteger,connectivity> & object );

} // namespace DGtal


///////////////////////////////////////////////////////////////////////////////
// Includes inline functions.
#include "DGtal/geometry/2d/FP.ih"

//                                                                           //
///////////////////////////////////////////////////////////////////////////////

#endif // !defined FP_h

#undef FP_RECURSES
#endif // else defined(FP_RECURSES)
