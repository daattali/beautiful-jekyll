/** 
 * @file Config.h.in
 * @author David Coeurjolly (\c david.coeurjolly@liris.cnrs.fr )
 * Laboratoire d'InfoRmatique en Image et Systèmes d'information - LIRIS (CNRS, UMR 5205), CNRS, France
 *
 * @date 2009/12/19
 * 
 * Input file for making Configuration file. 
 *
 * This file is part of the DGtal library.
 */

#include <iostream>
#include <string>


#define DGTAL_VERSION 0.1.r626

/*! \namespace DGtal
*  \brief \p DGtal is the top-level namespace which contains all DGtal
*         functions and types.
*/


/*! \namespace DGtal::experimental
*  \brief \p Experimental functions and types of the DGtal library.
*/


/*! \namespace DGtal::deprecated
*  \brief \p Deprecated functions and types of the DGtal library.
*/

/*! \namespace DGtal::Z2i
 *  \brief \p Z2i this namespace gathers  the standard of types for 2D imagery.
*/


/*! \namespace DGtal::Z3i
 *  \brief \p Z3i this namespace gathers  the standard of types for 3D imagery.
*/


/**
 * \mainpage DGtal - Digital Geometry Tools and Algorithms Library.
 *
 * @image  html logo_DGtal_small.png
 *
 *
 * @section intro_sec_dgtal Introduction
 *
 * @section manuals_dgtal DGtal user-guides
 *
 * - \ref dgtal_topology 
 * - \ref board_export 
 * - \ref image_io 
 *
 * @section examples_sec_dgtal Code examples
 *
 * @section links_sec_dgtal Links
 *
 * <ul>
 * <li>Visit the <a href="http://liris.cnrs.fr/dgtal/">DGtal homepage</a>.</li>
 *  <li> LibBoard section page   </li>
 * </ul>
 *
 * @defgroup Concepts DGtal concepts
 * @defgroup Tests DGtal test files
 */
