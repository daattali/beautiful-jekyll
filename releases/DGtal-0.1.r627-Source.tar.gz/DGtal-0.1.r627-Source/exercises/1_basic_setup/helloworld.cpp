#include <stdio.h>
#include <iostream>

#include <DGtal/base/Common.h>


int main(int argc, char **argv)
{

  /**
   *
   * Create a simple sequence of instructions that prints out the
   * message "Helloworld" (in red) to the standard output with the
   * DGtal trace mecanism.
   *
   */

  return 0;
}
