#include <stdio.h>
#include <iostream>

#include <DGtal/base/Common.h>


int main(int argc, char **argv)
{

  /**
   *
   * Create an image (0,0)x(255,255) in which we can store small
   * unsigned integers. 
   *
   * HINTS: you can use the ImageContainerBySTLVector
   */

  /**
   *
   * Create a SVG export of the image. 
   *
   */

  return 0;
}
