#include <stdio.h>
#include <iostream>

#include <DGtal/base/Common.h>


int main(int argc, char **argv)
{

  /**
   *
   * Create the shape defined in the exercise a_initimage.
   *
   */

  /**
   *
   * Implements a simple 2-scan distance transformation computation with the
   * chamfer mask 3x3 with a=3 (vertical/horizontal step cost) and b=4
   * (diagonal step cost).
   *
   */

  /**
   *
   * Create a SVG export with different colormaps of the DT value.
   *
   */

  return 0;
}
