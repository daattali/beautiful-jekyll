/**
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 **/

#pragma once

/**
 * @file SeparableMetricHelper.h
 * @brief Basic functions associated to metrics used by separable volumetric algorithms.
 * @author David Coeurjolly (\c david.coeurjolly@liris.cnrs.fr )
 * Laboratoire d'InfoRmatique en Image et Systèmes d'information - LIRIS (CNRS, UMR 5205), CNRS, France
 *
 * @date 2010/08/01
 *
 * Header file for module PowerSeparableMetricHelper.cpp
 *
 * This file is part of the DGtal library.
 *
 * @see testDistanceTransformationND.cpp
 */

#if defined(PowerSeparableMetricHelper_RECURSES)
#error Recursive header files inclusion detected in PowerSeparableMetricHelper.h
#else // defined(PowerSeparableMetricHelper_RECURSES)
/** Prevents recursive inclusion of headers. */
#define PowerSeparableMetricHelper_RECURSES

#if !defined PowerSeparableMetricHelper_h
/** Prevents repeated inclusion of headers. */
#define PowerSeparableMetricHelper_h

//////////////////////////////////////////////////////////////////////////////
// Inclusions
#include <iostream>
#include <cmath>
#include "DGtal/base/Common.h"
#include "DGtal/kernel/NumberTraits.h"
#include "DGtal/kernel/CBoundedInteger.h"
#include "DGtal/base/BasicFunctors.h"
//////////////////////////////////////////////////////////////////////////////

namespace DGtal
{

  /////////////////////////////////////////////////////////////////////////////
  // template class PowerSeparableMetricHelper
  /**
   * Description of template class 'PowerSeparableMetricHelper' <p>
   * \brief Aim: Implements basic functions associated to metrics used
   * by separable volumetric algorithms.
   *
   * @tparam TAbscissa Type used to store the coordinaites of the Domain (model of CBoundedInteger).
   * @tparam TInternalValue the type used to store the internal
   * numbers for exact computations. More precisely,
   * TInternalValueType must be able to represent numbers of type
   * TAbscissa to the power tp (model of CBoundedInteger).
   * @tparam tp the order p of the L_p metric.
   *
   * @warning this  code is node GMP compliant
   * @todo Fix the integer type problems.
   */
  template <typename TPoint, typename TInternalValue, DGtal::uint32_t tp>
  struct PowerSeparableMetricHelper
  {
    // ----------------------- Standard services ------------------------------

    typedef TInternalValue InternalValue;
    typedef typename TPoint::Coordinate Abscissa;
    typedef TPoint Point;
    
    
    BOOST_CONCEPT_ASSERT(( CBoundedInteger<Abscissa> ));
    BOOST_CONCEPT_ASSERT(( CBoundedInteger<TInternalValue> ));

    /**
     * Static constants containing the power p of the Lp-metric.
     *
     */
    static const DGtal::uint32_t p = tp;

    
    enum Closest { FIRST=0, SECOND=1, BOTH=2};
    
    
    /** 
     * Given an origin and two points, this method decides which one
     * is closest to the origin. This method should be faster than
     * comparing distance values.
     * 
     * @param origin the origin
     * @param first  the first point
     * @param second the second point
     * 
     * @return a Closest enum: FIRST, SECOND or BOTH.
     */
    Closest closestPredicate(const Point &origin, 
			     const Point &first,
			     const Point &second) const
    {
      InternalValue a=NumberTraits<InternalValue>::ZERO,
	b=NumberTraits<InternalValue>::ZERO;
      
      for(typename Point::Dimension i=0; i <  Point::dimension; i++)
	{
	  a += power(abs (origin[i] - first[i]));
	  b += power(abs (origin[i] - second[i]));
	}
      if (a<b)
	return FIRST;
      else
	if (a>b)
	  return SECOND;
	else
	  return BOTH;
    }

      /** 
     * Given three sites (a,b,c) and a straight line (startingPoint,
     * dim), we detect if the voronoi cells of a and c @e hide the
     * voronoi cell of c on the straight line.
     * 
     * @param a a site
     * @param b a site
     * @param c a site
     * @param startingPoint starting point of the straight line
     * @param dim direction of the straight line
     * 
     * @return true if (a,c) hides b.
     */
    bool hiddenBy(const Point &a, 
                  const Point &b,
                  const Point &c, 
                  const Point &startingPoint,
                  const typename Point::UnsignedComponent dim) const
    {
      ASSERT(false && "Not-Yet-Implemented");
    }

  }; // end of class PowerSeparableMetricHelper

  // ------------------------------------------------------------------------
  // -----------------------  Specializations   ------------------------------
  // ------------------------------------------------------------------------

  /**
   * L_2 specialization
   *
   */
  template <typename TPoint, typename TInternalValue>
  struct PowerSeparableMetricHelper<TPoint, TInternalValue, 2>
  {
    typedef TInternalValue InternalValue;
    typedef typename TPoint::Coordinate Abscissa;
    typedef TPoint Point;
 
    static const DGtal::uint32_t p = 2;

    Closest closestPredicate(const Point &origin, 
			     const Point &first,
			     const Point &second) const
    {
      InternalValue a=NumberTraits<InternalValue>::ZERO,
	b=NumberTraits<InternalValue>::ZERO;
      
      for(typename Point::Dimension i=0; i <  Point::dimension; i++)
	{
	  a += (origin[i] - first[i])*(origin[i] - first[i]);
	  b += (origin[i] - second[i])*(origin[i] - second[i]);
	}
      if (a<b)
	return FIRST;
      else
	if (a>b)
	  return SECOND;
	else
	  return BOTH;
    }

      /** 
     * Given three sites (a,b,c) and a straight line (startingPoint,
     * dim), we detect if the voronoi cells of a and c @e hide the
     * voronoi cell of c on the straight line.
     * 
     * @param a a site
     * @param b a site
     * @param c a site
     * @param startingPoint starting point of the straight line
     * @param dim direction of the straight line
     * 
     * @return true if (a,c) hides b.
     */
    bool hiddenBy(const Point &u, 
                  const Point &v,
                  const Point &w, 
                  const Point &startingPoint,
                  const typename Point::UnsignedComponent dim) const
    {
      //decide if (a,c) hide b in the lines (startingPoint, dim)

      Abscissa a,b, c;

      a = v[dim] - u[dim];
      b = w[dim] - v[dim];
      c = a + b;  
  
      Abscissa d2_v=0, d2_u=0 ,d2_w=0;

      for(Dimension i  = 0 ; i < Point::dimension ; i++)
	if (i != dim)
	  {
	    d2_u += (u[i] - startingPoint[i] ) *(u[i] - startingPoint[i] );
	    d2_v += (v[i] - startingPoint[i] ) *(v[i] - startingPoint[i] );
	    d2_w += (w[i] - startingPoint[i] ) *(w[i] - startingPoint[i] );
	  }
 
      return (c * d2_v -  b*d2_u - a*d2_w - a*b*c) > 0 ; 
    }
  
  };

  /**
   * L_1 specialization
   *
   */
  template <typename TPoint, typename TInternalValue>
  struct PowerSeparableMetricHelper<TPoint, TInternalValue, 1>
  {
    
    typedef TInternalValue InternalValue;
    static const DGtal::uint32_t p = 1;
    typedef typename TPoint::Coordinate Abscissa;
    typedef TPoint Point;
    

    enum Closest { FIRST=0, SECOND=1, BOTH=2};
    
    
    Closest closestPredicate(const Point &origin, 
			     const Point &first,
			     const Point &second) const
    {
      InternalValue a=(origin-first).norm(Point::L_1),
	b=(origin-second).norm(Point::L_1);
      
      if (a<b)
	return FIRST;
      else
	if (a>b)
	  return SECOND;
	else
	  return BOTH;
    }

      /** 
     * Given three sites (a,b,c) and a straight line (startingPoint,
     * dim), we detect if the voronoi cells of a and c @e hide the
     * voronoi cell of c on the straight line.
     * 
     * @param a a site
     * @param b a site
     * @param c a site
     * @param startingPoint starting point of the straight line
     * @param dim direction of the straight line
     * 
     * @return true if (a,c) hides b.
     */
    bool hiddenBy(const Point &u, 
                  const Point &v,
                  const Point &w, 
                  const Point &startingPoint,
                  const typename Point::UnsignedComponent dim) const
    {
      ASSERT(false && "Not-Yet-Implemented");
      Abscissa uv, vw;
      
      
    }

  }; // end of class PowerSeparableMetricHelper

  /**
   * L_infinity specialization
   *
   */
  template <typename TPoint, typename TInternalValue>
  struct PowerSeparableMetricHelper<TPoint, TInternalValue, 0>
  {
    typedef TInternalValue InternalValue;
    static const DGtal::uint32_t p = 0;
    typedef typename TPoint::Coordinate Abscissa;
    typedef TPoint Point;
 

     enum Closest { FIRST=0, SECOND=1, BOTH=2};
    
    
    Closest closestPredicate(const Point &origin, 
			     const Point &first,
			     const Point &second) const
    {
      InternalValue a=(origin-first).norm(Point::L_infty),
	b=(origin-second).norm(Point::L_infty);
      
      if (a<b)
	return FIRST;
      else
	if (a>b)
	  return SECOND;
	else
	  return BOTH;
    }

      /** 
     * Given three sites (a,b,c) and a straight line (startingPoint,
     * dim), we detect if the voronoi cells of a and c @e hide the
     * voronoi cell of c on the straight line.
     * 
     * @param a a site
     * @param b a site
     * @param c a site
     * @param startingPoint starting point of the straight line
     * @param dim direction of the straight line
     * 
     * @return true if (a,c) hides b.
     */
    bool hiddenBy(const Point &a, 
                  const Point &b,
                  const Point &c, 
                  const Point &startingPoint,
                  const typename Point::UnsignedComponent dim) const
    {
      ASSERT(false && "Not-Yet-Implemented");
    }
  }; // end of class PowerSeparableMetricHelper


} // namespace DGtal


//                                                                           //
///////////////////////////////////////////////////////////////////////////////

#endif // !defined PowerSeparableMetricHelper_h

#undef PowerSeparableMetricHelper_RECURSES
#endif // else defined(PowerSeparableMetricHelper_RECURSES)
