/**
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 **/

#pragma once

/**
 * @file SeparableMetricTraits.h
 * @author David Coeurjolly (\c david.coeurjolly@liris.cnrs.fr )
 * Laboratoire d'InfoRmatique en Image et Systèmes d'information - LIRIS (CNRS, UMR 5205), CNRS, France
 *
 * @date 2010/08/01
 *
 * Header file for module SeparableMetricTraits.cpp
 *
 * This file is part of the DGtal library.
 */

#if defined(SeparableMetricTraits_RECURSES)
#error Recursive header files inclusion detected in SeparableMetricTraits.h
#else // defined(SeparableMetricTraits_RECURSES)
/** Prevents recursive inclusion of headers. */
#define SeparableMetricTraits_RECURSES

#if !defined SeparableMetricTraits_h
/** Prevents repeated inclusion of headers. */
#define SeparableMetricTraits_h

//////////////////////////////////////////////////////////////////////////////
// Inclusions
#include <iostream>
#include <cmath>
#include "DGtal/base/Common.h"
#include "DGtal/kernel/IntegerTraits.h"
//////////////////////////////////////////////////////////////////////////////
#include <boost/concept_check.hpp>

namespace DGtal
{

  /////////////////////////////////////////////////////////////////////////////
  // template class SeparableMetricTraits
  /**
   * Description of template class 'SeparableMetricTraits' <p>
   * \brief Aim: Implements basic functions associated to metrics used
   * by separable volumetric algorithms.
   *
   * @tparam TAbscissa Type used to store the coordinaites of the Domain.
   * @tparam TInternalValue the type used to store the internal
   * numbers for exact computations. More precisely,
   * TInternalValueType must be able to represent numbers of type
   * TAbscissa to the power tp
   * @tparam tp the order p of the L_p metric.
   *
   * @warning this  code is node GMP compliant
   * @todo Fix the integer type problems.
   */
  template <typename TAbscissa, typename TInternalValue, DGtal::uint32_t tp>
  struct SeparableMetricTraits
  {
    // ----------------------- Standard services ------------------------------

    typedef TInternalValue InternalValue;
    typedef TAbscissa Abscissa;

    /**
     * Static constants containing the power p of the Lp-metric.
     *
     */
    static const DGtal::uint32_t p = tp;


    /**
     * Returns an approximation (double) of the InternalValues
     * associated to the metric. 
     *
     * @param aInternalValue the internal value to convert
     *
     * @return the converted value.
     */
    double getApproxValue( const InternalValue & aInternalValue ) const
    {
      return std::pow( IntegerTraits<InternalValue>::castToDouble(aInternalValue),
		      (double) 1.0 / p);
    }

    /**
     * Returns the height at a point  pos of a Lp-parabola with
     * center  ci and height hi.
     *
     * @param pos an abscissa.
     * @param ci center of the Lp-parabola.
     * @param hi height of the Lp-parabola.
     *
     * @return the height of the parabola (ci,hi) at pos.
     */
    InternalValue F ( const Abscissa pos, const Abscissa ci, const InternalValue hi ) const
    {
      return std::pow( fabs(IntegerTraits<Abscissa>::castToDouble(pos - ci)),
		       (double)p) + hi;
    }

    /**
     * Returns the height at a point  pos of a reversed Lp-parabola with
     * center  ci and height hi.
     *
     * @param pos an abscissa.
     * @param ci center of the Lp-parabola.
     * @param hi height of the Lp-parabola.
     *
     * @return the height of the reversed parabola (ci,hi) at pos.
     */
    InternalValue reversedF ( const Abscissa pos, const Abscissa ci, const InternalValue hi ) const
    {
      return hi - std::pow( fabs((double )pos - ci) , (double)p);
    }


    /**
     * Returns the InternalValue value of order p for a given
     * position. Basically, its computes @paramp pos^p.
     *
     * @param pos the value of type Abscissa
     *
     * @return the InternaValue value.
     */
    InternalValue power ( const Abscissa pos ) const
    {
      return ( InternalValue ) std::pow ( pos, p );
    }


    /**
     * Returns the abscissa of the intersection point between two reversed
     * Lp-parabolas (ci,hi) and (cj,hj).
     *
     * @param ci center of the first Lp-parabola.
     * @param hi height of the first Lp-parabola power p (hi = real height^p)
     * @param cj center of the first Lp-parabola.
     * @param hj height of the first Lp-parabola power p (hj = real height^p).
     *
     * @return
     */
    Abscissa reversedSep ( const Abscissa i, const InternalValue hi, const Abscissa j, const InternalValue hj ) const
    {
      ASSERT(false && "Not-Yet-Implemented");
    }
    
    /**
     * Returns the abscissa of the intersection point between two
     * Lp-parabolas (ci,hi) and (cj,hj).
     *
     * @param ci center of the first Lp-parabola.
     * @param hi height of the first Lp-parabola power p (hi = real height^p)
     * @param cj center of the first Lp-parabola.
     * @param hj height of the first Lp-parabola power p (hj = real height^p).
     *
     * @return
     */
    Abscissa Sep ( const Abscissa i, const InternalValue hi, const Abscissa j, const InternalValue hj ) const
    {
      ASSERT(false && "Not-Yet-Implemented");
    }


  }; // end of class SeparableMetricTraits

  // ------------------------------------------------------------------------
  // -----------------------  Specializations   ------------------------------
  // ------------------------------------------------------------------------

  /**
   * L_2 specialization
   *
   */
  template <typename TAbscissa, typename TInternalValue>
  struct SeparableMetricTraits<TAbscissa, TInternalValue, 2>
  {
    typedef TInternalValue InternalValue;
    typedef TAbscissa Abscissa;
		
    static const DGtal::uint32_t p = 2;

    inline double getApproxValue ( const InternalValue & aInternalValue ) const
    {
      return ( double ) sqrt ( IntegerTraits<InternalValue>::castToDouble(aInternalValue) );
    }

    inline InternalValue F ( const Abscissa pos, 
			     const Abscissa ci, 
			     const InternalValue hi ) const
    {
      return ( pos - ci ) * ( pos - ci ) + hi;
    }

    inline InternalValue reversedF ( const Abscissa pos, 
				     const Abscissa ci, 
				     const InternalValue hi ) const
    {
      return hi - ( pos - ci ) * ( pos - ci ) ;
    }


    inline Abscissa Sep ( const Abscissa i, const InternalValue hi, 
			  const Abscissa j, const InternalValue hj ) const
    {
      ///@warning GMP compliant problem here /
      return ( ( j*j - i*i ) + hj - hi )  / ( 2* ( j - i ) );
    }

    inline Abscissa reversedSep ( const Abscissa i, const InternalValue hi, 
				  const Abscissa j, const InternalValue hj ) const
    {
      ///@warning GMP compliant problem here /
      return ( ( i*i -j*j ) + hj - hi )  / ( 2* ( i - j ) );
    }

    inline InternalValue power ( const Abscissa i ) const
    {
      return (InternalValue) (i*i);
    }
  };

  /**
   * L_1 specialization
   *
   */
  template <typename TAbscissa, typename TInternalValue>
  struct SeparableMetricTraits<TAbscissa, TInternalValue, 1>
  {

    typedef TInternalValue InternalValue;
    static const DGtal::uint32_t p = 1;
    typedef TAbscissa Abscissa;
		

    inline double getApproxValue ( const InternalValue & aInternalValue ) const
    {
      return ( double ) aInternalValue;
    }
 
    inline InternalValue F ( const Abscissa pos, 
			     const Abscissa ci, 
			     const InternalValue hi ) const
    {
      return ( InternalValue ) std::abs ( (long int) pos - ci ) + hi;
    }

    inline InternalValue reversedF ( const Abscissa pos, 
				     const Abscissa ci, 
				     const InternalValue hi ) const
    {
      return ( InternalValue ) hi - abs ( pos - ci );
    }


    inline Abscissa Sep ( const Abscissa i, const InternalValue hi, 
			  const Abscissa j, const InternalValue hj ) const
    {
      if (hj >= hi + j - i)
        return IntegerTraits<Abscissa>::max();
      if (hi > hj + j - i)
        return IntegerTraits<Abscissa>::min();
      return (hj - hi + j + i) / 2;
    }

    inline Abscissa reversedSep ( const Abscissa i, const InternalValue hi, 
			  const Abscissa j, const InternalValue hj ) const
    {
      ASSERT(false && "Not-Yet-Implemented");
    }


    
    

    inline InternalValue power ( const Abscissa i ) const
    {
      return (InternalValue) std::abs((long int)i);
    }

  }; // end of class SeparableMetricTraits

  /**
   * L_infinity specialization
   *
   */
  template <typename TAbscissa, typename TInternalValue>
  struct SeparableMetricTraits<TAbscissa, TInternalValue, 0>
  {
    typedef TAbscissa Abscissa;
    typedef TInternalValue InternalValue;
    static const DGtal::uint32_t p = 0;
 
    inline double getApproxValue ( const InternalValue & aInternalValue ) const
    {
      return ( double ) aInternalValue;
    }

    inline InternalValue F ( const Abscissa pos, const Abscissa ci, 
			     const InternalValue hi ) const
    {
      return ( InternalValue ) std::max( (Abscissa)std::abs ( (long int)pos - ci ) , (Abscissa) hi);
    }

    inline InternalValue reversedF ( const Abscissa pos, 
				     const Abscissa ci, 
				     const InternalValue hi ) const
    {
     return ( InternalValue ) std::min( 2*hi - (Abscissa)abs ( pos - ci ) , (Abscissa) hi);
    }


    inline Abscissa Sep ( const Abscissa i, const InternalValue hi,
			  const Abscissa j, const InternalValue hj ) const
    {
      if (hi <= hj)
        return std::max ((Abscissa)(i + hj), (Abscissa)(i + j) / 2);
      else
        return std::min ((Abscissa)(j - hi), (Abscissa)(i + j) / 2);
    }

    inline Abscissa reversedSep ( const Abscissa i, const InternalValue hi,
			  const Abscissa j, const InternalValue hj ) const
    {
      ASSERT(false && "not yet implemented");
    }

    

    inline InternalValue power ( const Abscissa i ) const
    {
      ///@todo define Abs somewhere
      return (InternalValue) std::abs((long int)i);
    }

  }; // end of class SeparableMetricTraits


} // namespace DGtal


///////////////////////////////////////////////////////////////////////////////
// Includes inline functions.
#include "DGtal/geometry/nd/volumetric/SeparableMetricTraits.ih"

//                                                                           //
///////////////////////////////////////////////////////////////////////////////

#endif // !defined SeparableMetricTraits_h

#undef SeparableMetricTraits_RECURSES
#endif // else defined(SeparableMetricTraits_RECURSES)
