#!/usr/bin/env python
# this installation script was originally written by Giles Hall @ DFCI

import os

def check_build_tools():
    path = os.environ['PATH']
    for cmd in ('make', 'swig'):
        fq = None
        for dir in path.split( ':' ):
            testcmd = os.path.join( dir, cmd )
            try:
                os.stat( testcmd )
            except:
                continue
            fq = testcmd
        if not fq:
            print "Could not necessary build command: %s" % cmd
            return False
    print "Found make and swig."
    return True

def build_wrappers():
    cwd = os.getcwd()
    os.chdir( 'src' )
    os.system( 'make all' )
    try:
        os.rename('AffyFileParser/extension/AffyFileParser.py', 'xMAN/AffyFileParser.py')
    except:
        pass
    os.chdir( cwd )

def clean_wrappers():
    cwd = os.getcwd()
    os.chdir( 'src' )
    os.system( 'make clean' )
    try:
        os.unlink('xMAN/AffyFileParser.py')
    except:
        pass

    os.chdir( cwd )

def call_distutils():
    from distutils.core import setup, Extension
    setup(
        name="xMAN",
        version="09252006",
        description="xMAN: eXtreme MApping of oligoNucleotide",

        long_description =
        '''
        ''',

        platforms = 'Linux/Unix/Cygwin/MacOSX',
        license = 'Liu Lab License',
        author="Liu Lab",
        author_email='weili@jimmy.harvard.edu',
        url="http://chip.dfci.harvard.edu/~wli/xMAN",
        options={'build_ext':{'swig_opts':'-c++'}},
        packages=["xMAN"],
        package_dir = {
           'xMAN':'src/xMAN',
           'AffyFileParser':'src/AffyFileParser',
        },
        ext_package='xMAN',
        scripts=['scripts/xMAN'],
        ext_modules = [
            Extension( '_AffyFileParser',
                sources = [
                    'src/AffyFileParser/affymetrix/BPMAPFileData.cpp',
                    'src/AffyFileParser/affymetrix/BPMAPFileWriter.cpp',
                    'src/AffyFileParser/affymetrix/CDFFileData.cpp',
                    'src/AffyFileParser/affymetrix/FileIO.cpp',
                    'src/AffyFileParser/affymetrix/FileWriter.cpp',
                    'src/AffyFileParser/extension/AffyFileParser_wrap.cpp',
                    ],
                extra_compile_args = ['-w'],
                include_dirs=['src/AffyFileParser/affymetrix'],
            ),
        ],

    )

if check_build_tools():
    clean_wrappers()
    build_wrappers()
    call_distutils()
    clean_wrappers()
