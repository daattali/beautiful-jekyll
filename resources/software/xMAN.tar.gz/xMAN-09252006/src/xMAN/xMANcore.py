#!/usr/bin/env python
# weili@jimmy.harvard.edu
'''
xMAN: Extreme MApping of Oligonucleotide

Full mapping:
Index the original seq as xMAN.chip[seq2num(seq)] = _encode(features).
key is a uniq long int representing each seq.
value is a long int or list if multiple spots have exactly the same seq.
Search the whole genome for this unique sequences and get all the hits from both strands as
xMAN.genome[seq2num(PMProbe)] = _encode(seqid, pos).
value is a long int or list if one seq has multiple genome hits.

(Optional) two stage Redundance Removal (Li W et al. Bioinformatics ISMB2005):
one seq only has one genome hit within certain distance (1 kb).
If multi spots have exactly the same seq, we will randomly choose only one spot.
The seq will be completely removed from the mapping if it has more than maxSeqCopy hits along the genome.
'''

import sys, random, time
from numarray import *


#Define exceptions
class xMANError(Exception): pass
class OutOfRangeError(Exception): pass
class NotPosIntegerError(Exception): pass
class InvalidSeqError(Exception): pass



class xMAN(object):
    '''xMAN base class'''

    def __init__(self):
        self.time = time.time()                     # running time
        self.baseindex={'A':0,'C':1,'G':2,'T':3, 'a':0, 'c':1, 'g':2,'t':3}      # base 2 int
        self.baseindexrev={0:'A',1:'C',2:'G',3:'T'}                              # int 2 base
        self.copynum = 1000000.0                                                 # denominator of copy number
        self.bit = 32                               # number of bit for encode and decode
        self.lseq = 0                               # sequence length
        self.nseq = 0                               # number of unique sequence
        self.nspot = 0                              # number of unque probe spots (loc on chip)
        self.nseqmspots = 0                         # number of seq with multi array spots
        self.nseqmhits = []                         # seq list with multi genomic hits
        self.nseqmeas = 0                           # number of seq measurements
        self.failseqs = []                          # list of seqs with no hit along the genome
        self.genome = {}                            # genome[seqnum] = seqID.pos or list if >1
        self.chip = {}                              # chip[seqnum] = features or list if >1
        self.genomeloc = {}                         # genomeloc[seqID.pos]  = seqnum
        self.chrid = []                             # list of chromosomes


    def _seq2num(self, seq):
        '''_seq2num(self, seq)
        encode the probe sequence as an integer
        '''
        sum=0
        lseq=len(seq)
        for i, base in enumerate(seq):
            if self.baseindex.has_key(base):
                sum += self.baseindex[base]<<(lseq-i-1)*2L
            else:
                raise InvalidSeqError, 'Invalid DNA sequence %s' % (base)
        return sum


    def _num2seq(self, sum, lseq = 25):
        '''_num2seq(sum, lseq=25)
        decode the integer as a probe sequence
        '''
        if sum <0 or not (type(sum) == int or type(sum) == long):
            raise NotPosIntegerError
        seq = []
        for i in range(lseq-1, -1, -1):
            seq.append(self.baseindexrev[ (sum >> i *2L) & 03 ])
        return ''.join(seq)




    def _encode(self,  arg):
        '''_encode(arg), each iterm is 32 bit, arg is a tuple or list
        make the value in look-up table self.genome[seqnum] or self.chip[seqnum]
        _encode((x, y, z)) return  z.y.x
        '''
        code = 0
        if max(arg) >= (1 << self.bit):
            raise OutOfRangeError, 'input number is too big, no enough bit'
        for i, x in enumerate(arg):
            if x <0 or not (type(x) == int or type(x) == long):
                raise NotPosIntegerError
            code +=  ( x << (self.bit * i) )
        return code


    def _decode(self, code, narg):
        '''_decode(code, narg),
        code: from self._encode; narg: number of args
        _decode(z.y.x, 3) return (x, y, z)
        '''
        args = []
        for i in xrange(narg):
            args.append(code & 037777777777)
            code = code >> self.bit
        return args

    def _seqnumRC(self, seqnum, lseq = 25):
        '''_seqnumRC(seqnum, lseq = 25); reverse complement the seqnum
        return the seqnum
        '''
        nbit = lseq * 2
        seqnum = (1<<nbit)-1 - seqnum         #reverse
        rev = 0
        for i in range(lseq):
            rev +=(seqnum & 03) << (nbit -i*2 -2)
            seqnum = seqnum >>2
        return rev

    def _ncopy(self, x):
        '''_ncopy(x), return number of elements in x, x could be a list or long integer
        return 0 if x is 0
        '''
        if  type(x) == list:
            return len(x)
        elif x:
            return 1
        else:
            return 0


    def IndexProbe(self, seqiter):
        '''
        IndexProbeIterator(self, seqiter):
        seqiter: iterator, return seq.
        if return tuple (seq, ) only, feature list will be seq index

        return self.genome[seqnum] = genomic.location;
        seqnum (from the self._seq2num) is a integer for the unique seq
        genome.location is a int(long) encoded from  self._encode(pos, seqID).
        if 1 seq has multiple genomic locations,
        genome[seqnum] will be a list of all the genome.location otherwise.

        chip.location is a int(long) encoded from feature.
        if 1  seq has multiple spots,
        chip[seqnum] will be a list of all the chip.location.
        '''
        self.genome, self.chip = {}, {}
        for i, seq in enumerate(seqiter):
            if i == 0:                  # first one
                self.lseq = len(seq)
                self.lseqbit = 2 ** (self.lseq *2) - 1
            if i % 1000000 ==0 :
                print >>sys.stderr,  'Indexing ', i, time.time() -self.time
            if len(seq) != self.lseq:
                raise Exception, 'sequences are in different length: first seq %s, current seq %s' % (self.lseq, len(seq))
            seqnum = self._seq2num(seq)
            # genome locations
            self.genome[seqnum] = 0
            self.genome[self._seqnumRC(seqnum, self.lseq)] = 0     # probe's rev.comp
            #chip locations
            chip_loc = i
            if self.chip.has_key(seqnum)  :             #multiple probes for one seq
                if type(self.chip[seqnum]) != list:     #make a list
                    self.chip[seqnum]=[self.chip[seqnum]]
                if chip_loc not in self.chip[seqnum]:   #chip_loc not in the list
                    self.chip[seqnum].append(chip_loc)
                    print >> sys.stderr,'muliple chip locatoins', seq
            else:
                self.chip[seqnum] = chip_loc
        print >> sys.stderr, 'Time: Index probes ', time.time() -self.time


    def SearchGenome(self, arg):
        '''SearchGenome(chr1, chr2, ....):
        input: multiple fasta-format sequence files'''
        self.chrid = []                             # list of chromosomes
        if not self.lseq:
            raise Exception, 'please run IndexProbe first'
        for filename in arg:
            print >>sys.stderr, "Reading ", filename
            for line in open(filename):
                line = line.strip()
                if not line:
                    continue
                if line[0] == '>':
                    self.chrid.append(line[1:])
                    pos = 0             # position
                    seqnum=0            # integer from the sequence
                    basecount=0         # number of bases
                    chrindex = len(self.chrid)-1
                    continue
                line_len = len(line)
                if pos % 1000000 ==0 :
                    print >>sys.stderr,  pos, time.time() -self.time
                if line == 'N'* line_len:
                    pos += line_len
                    continue
                for i, base in enumerate(line):
                    if base not in 'ATCGatcg':     # repeat
                        basecount = 0
                        seqnum = 0
                        continue
                    else:                               # non-repeat
                        seqnum = (seqnum<<2L) + self.baseindex[base]
                        basecount += 1
                    if basecount < self.lseq:                  # less than seq
                        continue
                    # search begins
                    seqnum = seqnum & self.lseqbit
                    if not self.genome.has_key(seqnum):
                        continue
                    # find it
                    genome_loc = self._encode((pos+i-(self.lseq - 1), chrindex))
                    #first hit for this seq, init genome[seqnum] = 0
                    if not self.genome[seqnum]:
                        self.genome[seqnum] =  genome_loc
                        continue
                    if type(self.genome[seqnum]) != list:              #not a hit, make a list
                        self.genome[seqnum] = [self.genome[seqnum]]
                    #genome_loc is always unique during searching
                    self.genome[seqnum].append(genome_loc)
                    print >> sys.stderr,'muliple genomic locatoins',\
                    self._num2seq(seqnum, self.lseq), pos+i-(self.lseq - 1)
                pos += line_len
            print >> sys.stderr, 'Time: Searching ',filename,  time.time() -self.time
        self.GenomeLoc()


    def GenomeLoc(self):
        '''GenomeLoc(): reverse the self.genome{} dict to self.genomeloc
        return: self.genomeloc[chr_pos_value] = probe_seq_num
        and self.failseqs
        '''
        self.genomeloc = {}
        for i, seqnum in enumerate(self.genome.keys()):
            values = self.genome[seqnum]
            if not values:          # no match for this probe
                if not self.genome[self._seqnumRC(seqnum, self.lseq)] and \
                self.chip.has_key(seqnum):
                    self.failseqs.append(seqnum)
                continue
            if type(values) == int or type(values) == long:
                self.genomeloc[values] = seqnum
            elif type(values) == list :
                for x in values:
                    self.genomeloc[x] = seqnum
        self.failseqs = set(self.failseqs)
        print >> sys.stderr, 'Time: GenomeLoc ', time.time() -self.time



    def PrintOutMatch(self, outfile, features =[], dist = 0, maxSeqCopy = 99999999,
                      oneSeqPerLoc = False, SeqNames = [], res = 9999999):
        '''PrintOutMatch(self, outfile, features =[],dist = 0, maxSeqCopy = 99999999,
        oneSeqPerLoc = False, SeqNames = [], res = 1):

        features:       list of features
        dist:           one uniq seq only has one genomic hit within dist region,
                        set it to 0 (default) for full mapping
        maxProbCopy:    Those probes with >= maximum copy number will be discarded.
                        Default is 1e999.
        oneSeqPerLoc:   random select one seq per genomic loc. default False.
        SeqNames:       only those SeqNames will be printed out, default no restriction
        '''
        if not len(SeqNames):               # non-redundant, init SeqNames
            SeqNames = self.chrid
        self.nseqmeas = 0
        values = self.genomeloc.keys()
        values.sort()

        # non-redundant mapping
        if dist:
            FirstPos = 0
            for value in values:
                (pos, seqid) = self._decode(value, 2)
                seqnum = self.genomeloc[value]
                seqnumRC = self._seqnumRC(seqnum, self.lseq)
                seqname  = self.chrid[seqid]
                if seqname not in SeqNames:             # non-redundant, SeqNames
                    continue
                ProbeCopy = (self._ncopy(self.genome[seqnum]) + self._ncopy(
                    self.genome[seqnumRC])) / self.copynum
                if ProbeCopy > (maxSeqCopy / self.copynum):             # non-redundant, maxSeqCopy
                    continue
                if ProbeCopy > 1./self.copynum:             # non-redundant, multiple copy
                    mvalue = []
                    for x in [self.genome[seqnum], self.genome[seqnumRC]]:
                        if not x :
                            continue
                        if type(x) == int or type(x) == long:
                            mvalue.append(x)
                        elif type(x) == list:
                            mvalue.extend(x)
                    mvalue.sort()
                    for x in mvalue[mvalue.index(value)+1: ] :
                        if x -value < dist:
                            values.remove(x)

                allseqs = []                        # [(chip_num, strand, seq),...]
                if self.chip.has_key(seqnum):       # positive strand
                    if ProbeCopy > 1/self.copynum:
                        self.nseqmhits.append(seqnum)
                    strand = 1
                    seq = self._num2seq(seqnum, self.lseq)
                    if type(self.chip[seqnum]) == list:
                        for x in self.chip[seqnum]:
                            allseqs.append([x, strand, seq])
                    else:
                        allseqs.append([self.chip[seqnum], strand, seq])
                if self.chip.has_key(seqnumRC):      # negative strand
                    if ProbeCopy > 1/self.copynum:
                        self.nseqmhits.append(seqnumRC)
                    strand = 0
                    seq = self._num2seq(seqnumRC, self.lseq)
                    if type(self.chip[seqnumRC]) == list:
                        for x in self.chip[seqnumRC]:
                            allseqs.append([x, strand, seq])
                    else:
                        allseqs.append([self.chip[seqnumRC], strand, seq])

                if oneSeqPerLoc:                                # non-redundant, oneSeqPerLoc
                    allseqs =  [random.choice(allseqs)]

                # min probe resolution, res
                if ProbeCopy > 1./self.copynum and pos <  (FirstPos + res) and pos >= FirstPos:
                    continue
                else:
                    FirstPos = pos

                for (x, strand, seq) in allseqs:
                    print >> outfile, "%s\t"*6 % (seq, strand, seqname, pos, features[x], ProbeCopy)
                    self.nseqmeas += 1

        # full mapping
        else:
            for value in values:
                (pos, seqid) = self._decode(value, 2)
                seqnum = self.genomeloc[value]
                seqnumRC = self._seqnumRC(seqnum, self.lseq)
                seqname  = self.chrid[seqid]
                ProbeCopy = (self._ncopy(self.genome[seqnum]) + self._ncopy(
                    self.genome[seqnumRC])) / self.copynum
                allseqs = []                        # [(chip_num, strand, seq),...]
                if self.chip.has_key(seqnum):       # positive strand
                    if ProbeCopy > 1/self.copynum:
                        self.nseqmhits.append(seqnum)
                    strand = 1
                    seq = self._num2seq(seqnum, self.lseq)
                    if type(self.chip[seqnum]) == list:
                        for x in self.chip[seqnum]:
                            allseqs.append([x, strand, seq])
                    else:
                        allseqs.append([self.chip[seqnum], strand, seq])
                if self.chip.has_key(seqnumRC):      # negative strand
                    if ProbeCopy > 1/self.copynum:
                        self.nseqmhits.append(seqnumRC)
                    strand = 0
                    seq = self._num2seq(seqnumRC, self.lseq)
                    if type(self.chip[seqnumRC]) == list:
                        for x in self.chip[seqnumRC]:
                            allseqs.append([x, strand, seq])
                    else:
                        allseqs.append([self.chip[seqnumRC], strand, seq])
                for (x, strand, seq) in allseqs:
                    print >> outfile, "%s\t"*6 % (seq, strand, seqname, pos, features[x], ProbeCopy)
                    self.nseqmeas += 1
        print >> sys.stderr, 'Time: Print out ', time.time() -self.time


    def PrintOutNOMatch(self, outfile, features = []):
        ''' PrintOutNOMatch(self, outfile): seqs with no match to the genome
        '''
        ProbeCopy = 0
        for seqnum in self.failseqs:
            PMProbe = self._num2seq(seqnum, self.lseq)
            if type(self.chip[seqnum]) == list:
                tmp =  self.chip[seqnum]
            else:
                tmp = [self.chip[seqnum]]
            for x in tmp:
                print >> outfile, "%s\t"*6 % (PMProbe, 1, 'Nomatch', 0, features[x], ProbeCopy)
        # make one fake record if no fail probes
        if not self.failseqs:
            print >> outfile, "%s\t" * 6 % ('A'*self.lseq, 1, 'Nomatch', 0, features[0], ProbeCopy)
        print >> sys.stderr, 'Time: Print out failed sequences', time.time() -self.time


    def MakeSum(self):
        '''MakeSum(): Make the summary
        '''
        out = []
        self.nseq = len(self.chip)
        nspot = self.chip.values()
        nseqmspots = [x for x in nspot if type(x) == list]
        self.nseqmspots =  len(nseqmspots)
        self.nspot = len(nspot) - self.nseqmspots + sum([len(x) for x in nseqmspots])
        out.append("#NumUniqSeq\t\t\t\t%s" % (self.nseq))
        out.append("#NumSeq.MultEntries\t\t%s" % (self.nseqmspots))
        out.append("#NumQueryEntries\t\t\t%s" % (self.nspot))
        out.append("#NumSeq.MultGenomeHits\t\t%s" % (len(set(self.nseqmhits))))
        out.append("#NumSeq.NOGenomeHits\t\t%s" % (len(self.failseqs)))
        out.append("#NumSeq.TotalMeasurements\t%s" % (self.nseqmeas))
        return '\n'.join(out)


'''
class FastaFile:
    def __init__(self, filehandle):
        self.filehandle = filehandle
        self.line = 'firstline'

    def next(self):
        while self.line:
            self.line = self.filehandle.readline()
            x = self.line.strip()
            if not x:
                continue
            if x[0] == '>':
                self.filehandle.seek(-1 * len(self.line), 1)     # go back to the previous line
                raise StopIteration
            return x
        raise StopIteration

    def __iter__(self):
        return self

    def header(self):
        while self.line:
            self.line = self.filehandle.readline()
            if self.line[0] == '>':
                return self.line[1:].strip()
        return ''


'''
