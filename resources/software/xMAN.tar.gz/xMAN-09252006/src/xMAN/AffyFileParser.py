# This file was created automatically by SWIG.
# Don't modify this file, modify the SWIG interface instead.
# This file is compatible with both classic and new-style classes.

import _AffyFileParser

def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "this"):
        if isinstance(value, class_type):
            self.__dict__[name] = value.this
            if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
            del value.thisown
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static) or hasattr(self,name) or (name == "thisown"):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0
del types


_AFFY_BASE_TYPE_H = _AffyFileParser._AFFY_BASE_TYPE_H
class IntervalEntry(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, IntervalEntry, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, IntervalEntry, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ IntervalEntry instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["seq"] = _AffyFileParser.IntervalEntry_seq_set
    __swig_getmethods__["seq"] = _AffyFileParser.IntervalEntry_seq_get
    if _newclass:seq = property(_AffyFileParser.IntervalEntry_seq_get, _AffyFileParser.IntervalEntry_seq_set)
    __swig_setmethods__["probeSetName"] = _AffyFileParser.IntervalEntry_probeSetName_set
    __swig_getmethods__["probeSetName"] = _AffyFileParser.IntervalEntry_probeSetName_get
    if _newclass:probeSetName = property(_AffyFileParser.IntervalEntry_probeSetName_get, _AffyFileParser.IntervalEntry_probeSetName_set)
    __swig_setmethods__["start"] = _AffyFileParser.IntervalEntry_start_set
    __swig_getmethods__["start"] = _AffyFileParser.IntervalEntry_start_get
    if _newclass:start = property(_AffyFileParser.IntervalEntry_start_get, _AffyFileParser.IntervalEntry_start_set)
    __swig_setmethods__["stop"] = _AffyFileParser.IntervalEntry_stop_set
    __swig_getmethods__["stop"] = _AffyFileParser.IntervalEntry_stop_get
    if _newclass:stop = property(_AffyFileParser.IntervalEntry_stop_get, _AffyFileParser.IntervalEntry_stop_set)
    __swig_setmethods__["overlap"] = _AffyFileParser.IntervalEntry_overlap_set
    __swig_getmethods__["overlap"] = _AffyFileParser.IntervalEntry_overlap_get
    if _newclass:overlap = property(_AffyFileParser.IntervalEntry_overlap_get, _AffyFileParser.IntervalEntry_overlap_set)
    __swig_setmethods__["strand"] = _AffyFileParser.IntervalEntry_strand_set
    __swig_getmethods__["strand"] = _AffyFileParser.IntervalEntry_strand_get
    if _newclass:strand = property(_AffyFileParser.IntervalEntry_strand_get, _AffyFileParser.IntervalEntry_strand_set)
    def size(*args): return _AffyFileParser.IntervalEntry_size(*args)
    def __init__(self, *args):
        _swig_setattr(self, IntervalEntry, 'this', _AffyFileParser.new_IntervalEntry(*args))
        _swig_setattr(self, IntervalEntry, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_IntervalEntry):
        try:
            if self.thisown: destroy(self)
        except: pass


class IntervalEntryPtr(IntervalEntry):
    def __init__(self, this):
        _swig_setattr(self, IntervalEntry, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, IntervalEntry, 'thisown', 0)
        _swig_setattr(self, IntervalEntry,self.__class__,IntervalEntry)
_AffyFileParser.IntervalEntry_swigregister(IntervalEntryPtr)

class TagValuePairType(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, TagValuePairType, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, TagValuePairType, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ TagValuePairType instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["Tag"] = _AffyFileParser.TagValuePairType_Tag_set
    __swig_getmethods__["Tag"] = _AffyFileParser.TagValuePairType_Tag_get
    if _newclass:Tag = property(_AffyFileParser.TagValuePairType_Tag_get, _AffyFileParser.TagValuePairType_Tag_set)
    __swig_setmethods__["Value"] = _AffyFileParser.TagValuePairType_Value_set
    __swig_getmethods__["Value"] = _AffyFileParser.TagValuePairType_Value_get
    if _newclass:Value = property(_AffyFileParser.TagValuePairType_Value_get, _AffyFileParser.TagValuePairType_Value_set)
    def __eq__(*args): return _AffyFileParser.TagValuePairType___eq__(*args)
    def __init__(self, *args):
        _swig_setattr(self, TagValuePairType, 'this', _AffyFileParser.new_TagValuePairType(*args))
        _swig_setattr(self, TagValuePairType, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_TagValuePairType):
        try:
            if self.thisown: destroy(self)
        except: pass


class TagValuePairTypePtr(TagValuePairType):
    def __init__(self, this):
        _swig_setattr(self, TagValuePairType, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, TagValuePairType, 'thisown', 0)
        _swig_setattr(self, TagValuePairType,self.__class__,TagValuePairType)
_AffyFileParser.TagValuePairType_swigregister(TagValuePairTypePtr)

MAX_PROBE_SET_NAME_LENGTH = _AffyFileParser.MAX_PROBE_SET_NAME_LENGTH
class CCDFFileHeader(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFFileHeader, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFFileHeader, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFFileHeader instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetCols(*args): return _AffyFileParser.CCDFFileHeader_GetCols(*args)
    def GetRows(*args): return _AffyFileParser.CCDFFileHeader_GetRows(*args)
    def GetNumProbeSets(*args): return _AffyFileParser.CCDFFileHeader_GetNumProbeSets(*args)
    def GetNumQCProbeSets(*args): return _AffyFileParser.CCDFFileHeader_GetNumQCProbeSets(*args)
    def GetReference(*args): return _AffyFileParser.CCDFFileHeader_GetReference(*args)
    def __init__(self, *args):
        _swig_setattr(self, CCDFFileHeader, 'this', _AffyFileParser.new_CCDFFileHeader(*args))
        _swig_setattr(self, CCDFFileHeader, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFFileHeader):
        try:
            if self.thisown: destroy(self)
        except: pass


class CCDFFileHeaderPtr(CCDFFileHeader):
    def __init__(self, this):
        _swig_setattr(self, CCDFFileHeader, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFFileHeader, 'thisown', 0)
        _swig_setattr(self, CCDFFileHeader,self.__class__,CCDFFileHeader)
_AffyFileParser.CCDFFileHeader_swigregister(CCDFFileHeaderPtr)

UnknownProbeSetType = _AffyFileParser.UnknownProbeSetType
ExpressionProbeSetType = _AffyFileParser.ExpressionProbeSetType
GenotypingProbeSetType = _AffyFileParser.GenotypingProbeSetType
ResequencingProbeSetType = _AffyFileParser.ResequencingProbeSetType
TagProbeSetType = _AffyFileParser.TagProbeSetType
NoDirection = _AffyFileParser.NoDirection
SenseDirection = _AffyFileParser.SenseDirection
AntiSenseDirection = _AffyFileParser.AntiSenseDirection
class CCDFProbeInformation(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFProbeInformation, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFProbeInformation, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFProbeInformation instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetListIndex(*args): return _AffyFileParser.CCDFProbeInformation_GetListIndex(*args)
    def GetExpos(*args): return _AffyFileParser.CCDFProbeInformation_GetExpos(*args)
    def GetX(*args): return _AffyFileParser.CCDFProbeInformation_GetX(*args)
    def GetY(*args): return _AffyFileParser.CCDFProbeInformation_GetY(*args)
    def GetPBase(*args): return _AffyFileParser.CCDFProbeInformation_GetPBase(*args)
    def GetTBase(*args): return _AffyFileParser.CCDFProbeInformation_GetTBase(*args)
    def __init__(self, *args):
        _swig_setattr(self, CCDFProbeInformation, 'this', _AffyFileParser.new_CCDFProbeInformation(*args))
        _swig_setattr(self, CCDFProbeInformation, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFProbeInformation):
        try:
            if self.thisown: destroy(self)
        except: pass


class CCDFProbeInformationPtr(CCDFProbeInformation):
    def __init__(self, this):
        _swig_setattr(self, CCDFProbeInformation, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFProbeInformation, 'thisown', 0)
        _swig_setattr(self, CCDFProbeInformation,self.__class__,CCDFProbeInformation)
_AffyFileParser.CCDFProbeInformation_swigregister(CCDFProbeInformationPtr)

PROBE_SIZE = _AffyFileParser.PROBE_SIZE
class CCDFProbeGroupInformation(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFProbeGroupInformation, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFProbeGroupInformation, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFProbeGroupInformation instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetDirection(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetDirection(*args)
    def GetNumLists(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetNumLists(*args)
    def GetNumCells(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetNumCells(*args)
    def GetNumCellsPerList(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetNumCellsPerList(*args)
    def GetStart(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetStart(*args)
    def GetStop(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetStop(*args)
    def GetName(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetName(*args)
    def GetCell(*args): return _AffyFileParser.CCDFProbeGroupInformation_GetCell(*args)
    def __init__(self, *args):
        _swig_setattr(self, CCDFProbeGroupInformation, 'this', _AffyFileParser.new_CCDFProbeGroupInformation(*args))
        _swig_setattr(self, CCDFProbeGroupInformation, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFProbeGroupInformation):
        try:
            if self.thisown: destroy(self)
        except: pass


class CCDFProbeGroupInformationPtr(CCDFProbeGroupInformation):
    def __init__(self, this):
        _swig_setattr(self, CCDFProbeGroupInformation, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFProbeGroupInformation, 'thisown', 0)
        _swig_setattr(self, CCDFProbeGroupInformation,self.__class__,CCDFProbeGroupInformation)
_AffyFileParser.CCDFProbeGroupInformation_swigregister(CCDFProbeGroupInformationPtr)

PROBE_GROUP_SIZE = _AffyFileParser.PROBE_GROUP_SIZE
class CCDFProbeSetInformation(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFProbeSetInformation, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFProbeSetInformation, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFProbeSetInformation instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetProbeSetType(*args): return _AffyFileParser.CCDFProbeSetInformation_GetProbeSetType(*args)
    def GetDirection(*args): return _AffyFileParser.CCDFProbeSetInformation_GetDirection(*args)
    def GetNumLists(*args): return _AffyFileParser.CCDFProbeSetInformation_GetNumLists(*args)
    def GetNumGroups(*args): return _AffyFileParser.CCDFProbeSetInformation_GetNumGroups(*args)
    def GetNumCells(*args): return _AffyFileParser.CCDFProbeSetInformation_GetNumCells(*args)
    def GetNumCellsPerList(*args): return _AffyFileParser.CCDFProbeSetInformation_GetNumCellsPerList(*args)
    def GetProbeSetNumber(*args): return _AffyFileParser.CCDFProbeSetInformation_GetProbeSetNumber(*args)
    def GetGroupInformation(*args): return _AffyFileParser.CCDFProbeSetInformation_GetGroupInformation(*args)
    def __init__(self, *args):
        _swig_setattr(self, CCDFProbeSetInformation, 'this', _AffyFileParser.new_CCDFProbeSetInformation(*args))
        _swig_setattr(self, CCDFProbeSetInformation, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFProbeSetInformation):
        try:
            if self.thisown: destroy(self)
        except: pass


class CCDFProbeSetInformationPtr(CCDFProbeSetInformation):
    def __init__(self, this):
        _swig_setattr(self, CCDFProbeSetInformation, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFProbeSetInformation, 'thisown', 0)
        _swig_setattr(self, CCDFProbeSetInformation,self.__class__,CCDFProbeSetInformation)
_AffyFileParser.CCDFProbeSetInformation_swigregister(CCDFProbeSetInformationPtr)

PROBE_SET_SIZE = _AffyFileParser.PROBE_SET_SIZE
class CCDFProbeSetNames(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFProbeSetNames, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFProbeSetNames, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFProbeSetNames instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, CCDFProbeSetNames, 'this', _AffyFileParser.new_CCDFProbeSetNames(*args))
        _swig_setattr(self, CCDFProbeSetNames, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFProbeSetNames):
        try:
            if self.thisown: destroy(self)
        except: pass

    def Clear(*args): return _AffyFileParser.CCDFProbeSetNames_Clear(*args)
    def GetName(*args): return _AffyFileParser.CCDFProbeSetNames_GetName(*args)

class CCDFProbeSetNamesPtr(CCDFProbeSetNames):
    def __init__(self, this):
        _swig_setattr(self, CCDFProbeSetNames, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFProbeSetNames, 'thisown', 0)
        _swig_setattr(self, CCDFProbeSetNames,self.__class__,CCDFProbeSetNames)
_AffyFileParser.CCDFProbeSetNames_swigregister(CCDFProbeSetNamesPtr)

class CCDFQCProbeInformation(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFQCProbeInformation, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFQCProbeInformation, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFQCProbeInformation instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, CCDFQCProbeInformation, 'this', _AffyFileParser.new_CCDFQCProbeInformation(*args))
        _swig_setattr(self, CCDFQCProbeInformation, 'thisown', 1)
    def GetX(*args): return _AffyFileParser.CCDFQCProbeInformation_GetX(*args)
    def GetY(*args): return _AffyFileParser.CCDFQCProbeInformation_GetY(*args)
    def GetPLen(*args): return _AffyFileParser.CCDFQCProbeInformation_GetPLen(*args)
    def IsPerfectMatchProbe(*args): return _AffyFileParser.CCDFQCProbeInformation_IsPerfectMatchProbe(*args)
    def IsBackgroundProbe(*args): return _AffyFileParser.CCDFQCProbeInformation_IsBackgroundProbe(*args)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFQCProbeInformation):
        try:
            if self.thisown: destroy(self)
        except: pass


class CCDFQCProbeInformationPtr(CCDFQCProbeInformation):
    def __init__(self, this):
        _swig_setattr(self, CCDFQCProbeInformation, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFQCProbeInformation, 'thisown', 0)
        _swig_setattr(self, CCDFQCProbeInformation,self.__class__,CCDFQCProbeInformation)
_AffyFileParser.CCDFQCProbeInformation_swigregister(CCDFQCProbeInformationPtr)

QC_PROBE_SIZE = _AffyFileParser.QC_PROBE_SIZE
UnknownQCProbeSetType = _AffyFileParser.UnknownQCProbeSetType
CheckerboardNegativeQCProbeSetType = _AffyFileParser.CheckerboardNegativeQCProbeSetType
CheckerboardPositiveQCProbeSetType = _AffyFileParser.CheckerboardPositiveQCProbeSetType
HybNegativeQCProbeSetType = _AffyFileParser.HybNegativeQCProbeSetType
HybPositiveQCProbeSetType = _AffyFileParser.HybPositiveQCProbeSetType
TextFeaturesNegativeQCProbeSetType = _AffyFileParser.TextFeaturesNegativeQCProbeSetType
TextFeaturesPositiveQCProbeSetType = _AffyFileParser.TextFeaturesPositiveQCProbeSetType
CentralNegativeQCProbeSetType = _AffyFileParser.CentralNegativeQCProbeSetType
CentralPositiveQCProbeSetType = _AffyFileParser.CentralPositiveQCProbeSetType
GeneExpNegativeQCProbeSetType = _AffyFileParser.GeneExpNegativeQCProbeSetType
GeneExpPositiveQCProbeSetType = _AffyFileParser.GeneExpPositiveQCProbeSetType
CycleFidelityNegativeQCProbeSetType = _AffyFileParser.CycleFidelityNegativeQCProbeSetType
CycleFidelityPositiveQCProbeSetType = _AffyFileParser.CycleFidelityPositiveQCProbeSetType
CentralCrossNegativeQCProbeSetType = _AffyFileParser.CentralCrossNegativeQCProbeSetType
CentralCrossPositiveQCProbeSetType = _AffyFileParser.CentralCrossPositiveQCProbeSetType
CrossHybNegativeQCProbeSetType = _AffyFileParser.CrossHybNegativeQCProbeSetType
CrossHybPositiveQCProbeSetType = _AffyFileParser.CrossHybPositiveQCProbeSetType
SpatialNormalizationNegativeQCProbeSetType = _AffyFileParser.SpatialNormalizationNegativeQCProbeSetType
SpatialNormalizationPositiveQCProbeSetType = _AffyFileParser.SpatialNormalizationPositiveQCProbeSetType
class CCDFQCProbeSetInformation(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFQCProbeSetInformation, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFQCProbeSetInformation, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFQCProbeSetInformation instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetQCProbeSetType(*args): return _AffyFileParser.CCDFQCProbeSetInformation_GetQCProbeSetType(*args)
    def GetNumCells(*args): return _AffyFileParser.CCDFQCProbeSetInformation_GetNumCells(*args)
    def GetProbeInformation(*args): return _AffyFileParser.CCDFQCProbeSetInformation_GetProbeInformation(*args)
    def __init__(self, *args):
        _swig_setattr(self, CCDFQCProbeSetInformation, 'this', _AffyFileParser.new_CCDFQCProbeSetInformation(*args))
        _swig_setattr(self, CCDFQCProbeSetInformation, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFQCProbeSetInformation):
        try:
            if self.thisown: destroy(self)
        except: pass


class CCDFQCProbeSetInformationPtr(CCDFQCProbeSetInformation):
    def __init__(self, this):
        _swig_setattr(self, CCDFQCProbeSetInformation, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFQCProbeSetInformation, 'thisown', 0)
        _swig_setattr(self, CCDFQCProbeSetInformation,self.__class__,CCDFQCProbeSetInformation)
_AffyFileParser.CCDFQCProbeSetInformation_swigregister(CCDFQCProbeSetInformationPtr)

QC_PROBE_SET_SIZE = _AffyFileParser.QC_PROBE_SET_SIZE
class CCDFFileData(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CCDFFileData, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CCDFFileData, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxcdf::CCDFFileData instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def SetFileName(*args): return _AffyFileParser.CCDFFileData_SetFileName(*args)
    def GetFileName(*args): return _AffyFileParser.CCDFFileData_GetFileName(*args)
    def GetHeader(*args): return _AffyFileParser.CCDFFileData_GetHeader(*args)
    def GetError(*args): return _AffyFileParser.CCDFFileData_GetError(*args)
    def GetProbeSetName(*args): return _AffyFileParser.CCDFFileData_GetProbeSetName(*args)
    def GetChipType(*args): return _AffyFileParser.CCDFFileData_GetChipType(*args)
    def Read(*args): return _AffyFileParser.CCDFFileData_Read(*args)
    def ReadHeader(*args): return _AffyFileParser.CCDFFileData_ReadHeader(*args)
    def Exists(*args): return _AffyFileParser.CCDFFileData_Exists(*args)
    def Close(*args): return _AffyFileParser.CCDFFileData_Close(*args)
    def IsXDACompatibleFile(*args): return _AffyFileParser.CCDFFileData_IsXDACompatibleFile(*args)
    def GetProbeSetType(*args): return _AffyFileParser.CCDFFileData_GetProbeSetType(*args)
    def GetProbeSetInformation(*args): return _AffyFileParser.CCDFFileData_GetProbeSetInformation(*args)
    def GetQCProbeSetInformation(*args): return _AffyFileParser.CCDFFileData_GetQCProbeSetInformation(*args)
    def GetQCProbeSetInformation_By_Type(*args): return _AffyFileParser.CCDFFileData_GetQCProbeSetInformation_By_Type(*args)
    def __init__(self, *args):
        _swig_setattr(self, CCDFFileData, 'this', _AffyFileParser.new_CCDFFileData(*args))
        _swig_setattr(self, CCDFFileData, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CCDFFileData):
        try:
            if self.thisown: destroy(self)
        except: pass


class CCDFFileDataPtr(CCDFFileData):
    def __init__(self, this):
        _swig_setattr(self, CCDFFileData, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CCDFFileData, 'thisown', 0)
        _swig_setattr(self, CCDFFileData,self.__class__,CCDFFileData)
_AffyFileParser.CCDFFileData_swigregister(CCDFFileDataPtr)

BPMAP_FILE_HEADER_BYTES = _AffyFileParser.BPMAP_FILE_HEADER_BYTES
BPMAP_FILE_HEADER_LEN = _AffyFileParser.BPMAP_FILE_HEADER_LEN
PM_ONLY = _AffyFileParser.PM_ONLY
PM_MM = _AffyFileParser.PM_MM
PROBE_STORAGE_BUFFER_LENGTH = _AffyFileParser.PROBE_STORAGE_BUFFER_LENGTH
class GDACSequenceHitItemType(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, GDACSequenceHitItemType, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, GDACSequenceHitItemType, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxbpmap::GDACSequenceHitItemType instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["PMX"] = _AffyFileParser.GDACSequenceHitItemType_PMX_set
    __swig_getmethods__["PMX"] = _AffyFileParser.GDACSequenceHitItemType_PMX_get
    if _newclass:PMX = property(_AffyFileParser.GDACSequenceHitItemType_PMX_get, _AffyFileParser.GDACSequenceHitItemType_PMX_set)
    __swig_setmethods__["PMY"] = _AffyFileParser.GDACSequenceHitItemType_PMY_set
    __swig_getmethods__["PMY"] = _AffyFileParser.GDACSequenceHitItemType_PMY_get
    if _newclass:PMY = property(_AffyFileParser.GDACSequenceHitItemType_PMY_get, _AffyFileParser.GDACSequenceHitItemType_PMY_set)
    __swig_setmethods__["MMX"] = _AffyFileParser.GDACSequenceHitItemType_MMX_set
    __swig_getmethods__["MMX"] = _AffyFileParser.GDACSequenceHitItemType_MMX_get
    if _newclass:MMX = property(_AffyFileParser.GDACSequenceHitItemType_MMX_get, _AffyFileParser.GDACSequenceHitItemType_MMX_set)
    __swig_setmethods__["MMY"] = _AffyFileParser.GDACSequenceHitItemType_MMY_set
    __swig_getmethods__["MMY"] = _AffyFileParser.GDACSequenceHitItemType_MMY_get
    if _newclass:MMY = property(_AffyFileParser.GDACSequenceHitItemType_MMY_get, _AffyFileParser.GDACSequenceHitItemType_MMY_set)
    __swig_setmethods__["MatchScore"] = _AffyFileParser.GDACSequenceHitItemType_MatchScore_set
    __swig_getmethods__["MatchScore"] = _AffyFileParser.GDACSequenceHitItemType_MatchScore_get
    if _newclass:MatchScore = property(_AffyFileParser.GDACSequenceHitItemType_MatchScore_get, _AffyFileParser.GDACSequenceHitItemType_MatchScore_set)
    __swig_setmethods__["Position"] = _AffyFileParser.GDACSequenceHitItemType_Position_set
    __swig_getmethods__["Position"] = _AffyFileParser.GDACSequenceHitItemType_Position_get
    if _newclass:Position = property(_AffyFileParser.GDACSequenceHitItemType_Position_get, _AffyFileParser.GDACSequenceHitItemType_Position_set)
    __swig_setmethods__["PMProbe"] = _AffyFileParser.GDACSequenceHitItemType_PMProbe_set
    __swig_getmethods__["PMProbe"] = _AffyFileParser.GDACSequenceHitItemType_PMProbe_get
    if _newclass:PMProbe = property(_AffyFileParser.GDACSequenceHitItemType_PMProbe_get, _AffyFileParser.GDACSequenceHitItemType_PMProbe_set)
    __swig_setmethods__["ProbeLength"] = _AffyFileParser.GDACSequenceHitItemType_ProbeLength_set
    __swig_getmethods__["ProbeLength"] = _AffyFileParser.GDACSequenceHitItemType_ProbeLength_get
    if _newclass:ProbeLength = property(_AffyFileParser.GDACSequenceHitItemType_ProbeLength_get, _AffyFileParser.GDACSequenceHitItemType_ProbeLength_set)
    __swig_setmethods__["TopStrand"] = _AffyFileParser.GDACSequenceHitItemType_TopStrand_set
    __swig_getmethods__["TopStrand"] = _AffyFileParser.GDACSequenceHitItemType_TopStrand_get
    if _newclass:TopStrand = property(_AffyFileParser.GDACSequenceHitItemType_TopStrand_get, _AffyFileParser.GDACSequenceHitItemType_TopStrand_set)
    def __lt__(*args): return _AffyFileParser.GDACSequenceHitItemType___lt__(*args)
    __swig_setmethods__["PackedPMProbe"] = _AffyFileParser.GDACSequenceHitItemType_PackedPMProbe_set
    __swig_getmethods__["PackedPMProbe"] = _AffyFileParser.GDACSequenceHitItemType_PackedPMProbe_get
    if _newclass:PackedPMProbe = property(_AffyFileParser.GDACSequenceHitItemType_PackedPMProbe_get, _AffyFileParser.GDACSequenceHitItemType_PackedPMProbe_set)
    def __init__(self, *args):
        _swig_setattr(self, GDACSequenceHitItemType, 'this', _AffyFileParser.new_GDACSequenceHitItemType(*args))
        _swig_setattr(self, GDACSequenceHitItemType, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_GDACSequenceHitItemType):
        try:
            if self.thisown: destroy(self)
        except: pass


class GDACSequenceHitItemTypePtr(GDACSequenceHitItemType):
    def __init__(self, this):
        _swig_setattr(self, GDACSequenceHitItemType, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, GDACSequenceHitItemType, 'thisown', 0)
        _swig_setattr(self, GDACSequenceHitItemType,self.__class__,GDACSequenceHitItemType)
_AffyFileParser.GDACSequenceHitItemType_swigregister(GDACSequenceHitItemTypePtr)

HIT_ITEM_SIZE_WITH_PROBE_PAIRS = _AffyFileParser.HIT_ITEM_SIZE_WITH_PROBE_PAIRS
HIT_ITEM_SIZE_WITH_PM_ONLY = _AffyFileParser.HIT_ITEM_SIZE_WITH_PM_ONLY
class CGDACSequenceItem(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CGDACSequenceItem, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CGDACSequenceItem, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxbpmap::CGDACSequenceItem instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, CGDACSequenceItem, 'this', _AffyFileParser.new_CGDACSequenceItem(*args))
        _swig_setattr(self, CGDACSequenceItem, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CGDACSequenceItem):
        try:
            if self.thisown: destroy(self)
        except: pass

    def GetName(*args): return _AffyFileParser.CGDACSequenceItem_GetName(*args)
    def GroupName(*args): return _AffyFileParser.CGDACSequenceItem_GroupName(*args)
    def GetSeqVersion(*args): return _AffyFileParser.CGDACSequenceItem_GetSeqVersion(*args)
    def GetProbeMapping(*args): return _AffyFileParser.CGDACSequenceItem_GetProbeMapping(*args)
    def GetNumber(*args): return _AffyFileParser.CGDACSequenceItem_GetNumber(*args)
    def GetNumberHits(*args): return _AffyFileParser.CGDACSequenceItem_GetNumberHits(*args)
    def GetNumberParameters(*args): return _AffyFileParser.CGDACSequenceItem_GetNumberParameters(*args)
    def GetParameter(*args): return _AffyFileParser.CGDACSequenceItem_GetParameter(*args)
    def GetHitItem(*args): return _AffyFileParser.CGDACSequenceItem_GetHitItem(*args)

class CGDACSequenceItemPtr(CGDACSequenceItem):
    def __init__(self, this):
        _swig_setattr(self, CGDACSequenceItem, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CGDACSequenceItem, 'thisown', 0)
        _swig_setattr(self, CGDACSequenceItem,self.__class__,CGDACSequenceItem)
_AffyFileParser.CGDACSequenceItem_swigregister(CGDACSequenceItemPtr)

class CBPMAPFileData(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CBPMAPFileData, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CBPMAPFileData, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxbpmap::CBPMAPFileData instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, CBPMAPFileData, 'this', _AffyFileParser.new_CBPMAPFileData(*args))
        _swig_setattr(self, CBPMAPFileData, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CBPMAPFileData):
        try:
            if self.thisown: destroy(self)
        except: pass

    def SetFileName(*args): return _AffyFileParser.CBPMAPFileData_SetFileName(*args)
    def GetFileName(*args): return _AffyFileParser.CBPMAPFileData_GetFileName(*args)
    def Read(*args): return _AffyFileParser.CBPMAPFileData_Read(*args)
    def ReadHeader(*args): return _AffyFileParser.CBPMAPFileData_ReadHeader(*args)
    def Exists(*args): return _AffyFileParser.CBPMAPFileData_Exists(*args)
    def Close(*args): return _AffyFileParser.CBPMAPFileData_Close(*args)
    def GetError(*args): return _AffyFileParser.CBPMAPFileData_GetError(*args)
    def GetNumberSequences(*args): return _AffyFileParser.CBPMAPFileData_GetNumberSequences(*args)
    def GetVersion(*args): return _AffyFileParser.CBPMAPFileData_GetVersion(*args)
    def GetSequenceItem(*args): return _AffyFileParser.CBPMAPFileData_GetSequenceItem(*args)

class CBPMAPFileDataPtr(CBPMAPFileData):
    def __init__(self, this):
        _swig_setattr(self, CBPMAPFileData, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CBPMAPFileData, 'thisown', 0)
        _swig_setattr(self, CBPMAPFileData,self.__class__,CBPMAPFileData)
_AffyFileParser.CBPMAPFileData_swigregister(CBPMAPFileDataPtr)

BPMAP_VERSION = _AffyFileParser.BPMAP_VERSION
class CGDACSequenceItemWriter(CGDACSequenceItem):
    __swig_setmethods__ = {}
    for _s in [CGDACSequenceItem]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CGDACSequenceItemWriter, name, value)
    __swig_getmethods__ = {}
    for _s in [CGDACSequenceItem]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CGDACSequenceItemWriter, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxbpmapwriter::CGDACSequenceItemWriter instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, CGDACSequenceItemWriter, 'this', _AffyFileParser.new_CGDACSequenceItemWriter(*args))
        _swig_setattr(self, CGDACSequenceItemWriter, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CGDACSequenceItemWriter):
        try:
            if self.thisown: destroy(self)
        except: pass

    def GetError(*args): return _AffyFileParser.CGDACSequenceItemWriter_GetError(*args)
    def copyMe(*args): return _AffyFileParser.CGDACSequenceItemWriter_copyMe(*args)
    def __lt__(*args): return _AffyFileParser.CGDACSequenceItemWriter___lt__(*args)

class CGDACSequenceItemWriterPtr(CGDACSequenceItemWriter):
    def __init__(self, this):
        _swig_setattr(self, CGDACSequenceItemWriter, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CGDACSequenceItemWriter, 'thisown', 0)
        _swig_setattr(self, CGDACSequenceItemWriter,self.__class__,CGDACSequenceItemWriter)
_AffyFileParser.CGDACSequenceItemWriter_swigregister(CGDACSequenceItemWriterPtr)

class CBPMAPFileWriter(CBPMAPFileData):
    __swig_setmethods__ = {}
    for _s in [CBPMAPFileData]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CBPMAPFileWriter, name, value)
    __swig_getmethods__ = {}
    for _s in [CBPMAPFileData]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CBPMAPFileWriter, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ affxbpmapwriter::CBPMAPFileWriter instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, CBPMAPFileWriter, 'this', _AffyFileParser.new_CBPMAPFileWriter(*args))
        _swig_setattr(self, CBPMAPFileWriter, 'thisown', 1)
    def __del__(self, destroy=_AffyFileParser.delete_CBPMAPFileWriter):
        try:
            if self.thisown: destroy(self)
        except: pass

    def GetTpmapFileName(*args): return _AffyFileParser.CBPMAPFileWriter_GetTpmapFileName(*args)
    def SetTpmapFileName(*args): return _AffyFileParser.CBPMAPFileWriter_SetTpmapFileName(*args)
    def WriteBpmap(*args): return _AffyFileParser.CBPMAPFileWriter_WriteBpmap(*args)
    def TpmapExists(*args): return _AffyFileParser.CBPMAPFileWriter_TpmapExists(*args)
    def ReadTpmap(*args): return _AffyFileParser.CBPMAPFileWriter_ReadTpmap(*args)

class CBPMAPFileWriterPtr(CBPMAPFileWriter):
    def __init__(self, this):
        _swig_setattr(self, CBPMAPFileWriter, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CBPMAPFileWriter, 'thisown', 0)
        _swig_setattr(self, CBPMAPFileWriter,self.__class__,CBPMAPFileWriter)
_AffyFileParser.CBPMAPFileWriter_swigregister(CBPMAPFileWriterPtr)


