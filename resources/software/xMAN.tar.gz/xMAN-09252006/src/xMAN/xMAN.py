#!/usr/bin/env python
# weili@jimmy.harvard.edu


import sys, random, re, time
from xMANcore import xMAN
import AffyFileParser
import cPickle as Pickle
from numarray import *

class Mytpmap(object):
    '''read data in tpmapfile'''
    def __init__(self, tpmapname):
        self.seq = AffyFileParser.CGDACSequenceItem()
        self.hit = AffyFileParser.GDACSequenceHitItemType()
        bpmap = AffyFileParser.CBPMAPFileWriter()
        bpmap.SetTpmapFileName(tpmapname)
        print >> sys.stderr, 'Reading ', tpmapname
        if not bpmap.ReadTpmap():
            print bpmap.GetError()
            return
        self.bpmap = bpmap
        self.tpmapname = tpmapname

    def Makebpmap(self):
        '''Makebpmap()
        Make the bpmap file, binary format from tpmap file
        '''
        bpmapname = self.tpmapname +'.bpmap'
        self.bpmap.SetFileName(bpmapname)
        if not self.bpmap.WriteBpmap():
            print self.bpmap.GetError()
            return
        self.bpmap.Read()
        self.MakeSum()


    def MakeSum(self):
        '''MakeSum()
        Make the summary file for the bpmapfile
        '''
        parstr = ''
        self.nprobemeas = 0
        outfile = open(self.bpmap.GetFileName() + '.sum', 'w', 0)
        print >> outfile, "#version\t%s" % (self.bpmap.GetVersion())
        print >> outfile, "SeqID\tName\t#Hits\tGroupName\tVersion"
        for iseq in range(self.bpmap.GetNumberSequences() ):
            self.bpmap.GetSequenceItem(iseq, self.seq)
            print >> outfile, "%s\t"*5 % (self.seq.GetNumber(),self.seq.GetName(), \
                    self.seq.GetNumberHits(), self.seq.GroupName(),self.seq.GetSeqVersion() )
            # sum up number of probe measurements except for the FailProbe group
            if self.seq.GroupName() != 'FailProbe':
                self.nprobemeas += self.seq.GetNumberHits()
                continue
            # additional parameters in the FailProbe group
            for ipar in range(self.seq.GetNumberParameters()):
                x = self.seq.GetParameter(ipar)
                parstr += "%s\t%s\n" % (x.Tag, x.Value)
        print >> outfile, "#probe_measurements\t", self.nprobemeas
        print >> outfile, parstr



class Mybpmap(xMAN):
    '''bpmapfile object'''

    def __init__(self, bpmapname):
        xMAN.__init__(self)
        self.copynum = 1000000.0                                # denominator of copy number
        self.Chr = []                                           # chromosome information
        self.Position = []                                      # positions
        self.MatchScore = []                                    # copy number
        self.PMProbe = []                                       # probe seqs
        self.PMX = []                                           # PMX
        self.PMY = []                                           # PMY
        self.MMX = []                                           # MMX
        self.MMY = []                                           # MMY
        self.SeqNames = []                                      # chr in the orignal bpmap file
        self.bpmapname = bpmapname                  # file name
        self.seq = AffyFileParser.CGDACSequenceItem()       # Affy seq class
        self.hit = AffyFileParser.GDACSequenceHitItemType() # Affy hit structure
        self.bpmap = AffyFileParser.CBPMAPFileWriter()      # Affy bpmap class
        self.bpmap.SetFileName(self.bpmapname)
        print >> sys.stderr, 'Reading ', self.bpmapname
        if not self.bpmap.Read():
            print >> sys.stderr, self.bpmap.GetError()
            return

        # select genome group automatically
        group = {}
        for iseq in range(self.bpmap.GetNumberSequences() ):
            self.bpmap.GetSequenceItem(iseq, self.seq)
            if not group.has_key(self.seq.GroupName()):
                group[self.seq.GroupName()] = 0
            group[self.seq.GroupName()] += self.seq.GetNumberHits()
        self.genomegroup = sorted([(v, k) for (k, v) in group.items()], reverse = True)[0][1]
        self.group = group

        # get self.SeqNames
        for iseq in range(self.bpmap.GetNumberSequences() ):
            self.bpmap.GetSequenceItem(iseq, self.seq)
            if self.seq.GroupName() != self.genomegroup:
                continue
            self.SeqNames.append(self.seq.GetName())
        print >> sys.stderr, 'Time: Reading ', time.time() -self.time


    def Read(self,  *pars):
        '''Read(*pars):  Read array elements, copy from FileIO.py from MAT
                                    with minor modification
        *pars[optional]:    can be 'Chr','MatchScore'(copy_number/1e6), 'Position',
                            'PMProbe', 'PMX', 'PMY, MMX, MMY'
        So Read() will readl all elements of all the probes on the array
        '''

        # init
        if not pars:
            pars = self.pars
        else:
            pars = list(pars)
        print >> sys.stderr,  '  '.join(pars), time.asctime()
        print >> sys.stderr, 'All probes'
        if self.bpmap.GetNumberSequences() == 0:
            if not self.bpmap.Read():
                print >> sys.stderr, 'Error: ', self.bpmap.GetError()
                sys.exit()
        for name in pars:
            self.__setattr__(name, [])

        # read
        for iseq in range(self.bpmap.GetNumberSequences() ):
            self.bpmap.GetSequenceItem(iseq, self.seq)
            if self.seq.GroupName() != self.genomegroup:
                continue
            print >> sys.stderr, 'reading ', self.seq.GetName()
            # index for this seq
            index = arange(self.seq.GetNumberHits())
            for ihit in index:
                self.seq.GetHitItem(ihit, self.hit, 1)
                for name in pars:
                    self.__getattribute__(name).append(self.hit.__getattribute__(name))
        if len(self.PMProbe) == 0:
            raise Exception, 'NO data for this GenomeGrp ' +  self.genomegroup
        # MatchScore * 1e6 = copy number
        if pars.count('MatchScore') > 0:
            self.MatchScore = array(self.MatchScore, Float32) * self.copynum


    def MakeTpmap(self):
        '''MakeTpmap() Make the tpmap file, text format from bpmap file
        '''
        outfile = re.compile('bpmap$', re.I).sub('tpmap', self.bpmapname)
        if outfile == self.bpmapname:
            outfile = self.bpmapname +'.tpmap'
        outfile = open(outfile, 'w', 0)
        for iseq in range(self.bpmap.GetNumberSequences() ):
            self.bpmap.GetSequenceItem(iseq, self.seq)
            print >> outfile, "#seq_group_name\t%s" % (self.seq.GroupName())
            print >> outfile, "#version\t%s" % (self.seq.GetSeqVersion())
            for ihit in range( self.seq.GetNumberHits() ):
                self.seq.GetHitItem(ihit, self.hit, 1)
                print >> outfile, "%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d" % (self.hit.PMProbe, self.hit.TopStrand,\
                self.seq.GetName(),self.hit.Position, self.hit.PMX, self.hit.PMY, self.hit.MMX, self.hit.MMY)


    def BpmapSum(self):
        '''BpmapSum()
        Make the summary file for the bpmapfile
        '''
        nprobemeas = 0
        outfile = re.compile('bpmap$', re.I).sub('bpmap.sum', self.bpmapname)
        if outfile == self.bpmapname:
            outfile = self.bpmapname + '.sum'
        outfile = open(outfile, 'w',0)
        print >> outfile, "#version\t%s" % (self.bpmap.GetVersion())
        print >> outfile, "SeqID\tName\t#Hits\tGroupName\tVersion"
        for iseq in range(self.bpmap.GetNumberSequences() ):
            self.bpmap.GetSequenceItem(iseq, self.seq)
            nprobemeas += self.seq.GetNumberHits()
            print >> outfile, "%s\t"*5 % (self.seq.GetNumber(),self.seq.GetName(), \
                    self.seq.GetNumberHits(), self.seq.GroupName(),self.seq.GetSeqVersion() )
        print >> outfile, "#probe_measurements\t",nprobemeas


    def Run(self, arg):
        '''
        Run(self, *arg):
        arg:    list of fasta-format sequence files
        '''
        self.Read('PMProbe')
        self.IndexProbe(self.PMProbe)
        self.SearchGenome(arg)


    def PrintOut(self, outfile, dist = 0, maxSeqCopy = 99999999,
                      oneSeqPerLoc = False, SeqNames = [], res = 9999999):
        self.Read('PMX', 'PMY', 'MMX', 'MMY')
        features = []
        for i in xrange(len(self.PMX)):
            features.append("%d\t%d\t%d\t%d" % (self.PMX[i], self.PMY[i], self.MMX[i], self.MMY[i]))
       # genomic group
        print >> outfile, "#seq_group_name\t%s" % (self.genomegroup)
        print >> outfile, "#version\t%s" % ('.'.join(time.asctime().split()))
        self.PrintOutMatch(outfile, features, dist = dist, maxSeqCopy = maxSeqCopy,
                      oneSeqPerLoc = oneSeqPerLoc, SeqNames = SeqNames, res = res)
        # control group
        for iseq in range(self.bpmap.GetNumberSequences() ):
            self.bpmap.GetSequenceItem(iseq, self.seq)
            if self.seq.GroupName() == self.genomegroup:
                continue
            self.bpmap.GetSequenceItem(iseq, self.seq)
            print >> outfile, "#seq_group_name\t%s" % (self.seq.GroupName())
            print >> outfile, "#version\t%s" % (self.seq.GetSeqVersion())
            for ihit in range( self.seq.GetNumberHits() ):
                self.seq.GetHitItem(ihit, self.hit, 1)
                print >> outfile, "%s\t"*9 % (self.hit.PMProbe, self.hit.TopStrand,
                        self.seq.GetName(), self.hit.Position, self.hit.PMX,
                        self.hit.PMY, self.hit.MMX, self.hit.MMY, self.hit.MatchScore)

         # genome.group probes with no match along the genome
        print >> outfile, "#seq_group_name\tFailProbe"
        print >> outfile, "#version\t%s" % ('.'.join(time.asctime().split()))
        print >> outfile, self.MakeSum()    #additional parameters in the FailProbe group
        self.PrintOutNOMatch(outfile, features)


class Myseq(xMAN):
    '''pure sequence file object
    comment lines starting with # are omitted
    '''

    def __init__(self, filename):
        xMAN.__init__(self)
        self.filename  = filename
        self.copynum = 1

    def Run(self, arg):

        def SeqIterator():
            for x in open(self.filename):
                x = x.strip()
                if not x:
                    continue
                if x[0] == '#':
                    continue
                x = x.split()
                yield x[0]

        self.IndexProbe(SeqIterator())
        self.SearchGenome(arg)


    def PrintOut(self, outfile, dist = 0, maxSeqCopy = 99999999,
                      oneSeqPerLoc = False, SeqNames = [], res = 9999999):
        features = []
        for x in open(self.filename):
            x = x.strip()
            if not x:
                continue
            if x[0] == '#':
                continue
            features.append(x[self.lseq:].strip())

        self.PrintOutMatch(outfile, features, dist = dist, maxSeqCopy = maxSeqCopy,
                      oneSeqPerLoc = oneSeqPerLoc, SeqNames = SeqNames, res = res)

         # genome.group probes with no match along the genome
        self.PrintOutNOMatch(outfile, features)
        print >> outfile, "#version\t%s" % ('.'.join(time.asctime().split()))
        print >> outfile, self.MakeSum()




