#!/usr/bin/env python
# weili@jimmy.harvard.edu


import sys, unittest
import xMANcore
from numarray import *
xMANclass = xMANcore.xMAN()

class TestSeqNum(unittest.TestCase):

    def setUp(self):
        self.knownValues = (('TTTGAATATCTCAAGTTTTTGCTTT', 1117324806454911L),
            ('AACAAAAAAAGAACCTCACCATGAA', 17592729015520L),
            ('TTGGCTGTTATGAGTTGTTATGAGT', 1101638588625803L),
            ('AAAAAAAAA', 0)
                      )
        self.knownValuesEncode = (((3,4,500, 501), 39693309428869805171237474795523L),
            ((44,45,888,889), 70433836491561704858307927212076L)
                                 )
        self.knownSeq = (('atcgatcg', 'cgatcgat'),
            ('atccccggagagggagtttggaata', 'tattccaaactccctctccggggat')
                        )
        self.knownElements = ((2, 1),
            ([3,4,5,6], 4),
            (0, 0)
            )

    def test_seq2numKnownSeq(self):
        '''_seq2num should give known number with known seq
        '''
        for seq, num in self.knownValues:
            self.assertEqual(xMANclass._seq2num(seq),num)

    def test_seq2numBadSeq(self):
        '''_seq2num should fail with non-DNA sequences
        '''
        self.assertRaises(xMANcore.InvalidSeqError, xMANclass._seq2num, 'aad')

    def test_num2seqKnowNum(self):
        '''_num2seq should give known seq with known number
        '''
        for seq, num in self.knownValues:
            self.assertEqual(xMANclass._num2seq(num, lseq=len(seq)),seq)

    def test_num2seqBadNum(self):
        '''_num2seq should fail with negative or non-integer input
        '''
        self.assertRaises(xMANcore.NotPosIntegerError, xMANclass._num2seq, -3 ,2)
        self.assertRaises(xMANcore.NotPosIntegerError, xMANclass._num2seq, 3.4 ,2)

    def test_num2seqSanity(self):
        '''SanityCheck: _num2seq(_seq2num(seq), len(seq) should equal to seq
        '''
        for seq, num in self.knownValues:
            self.assertEqual(xMANclass._num2seq(xMANclass._seq2num(seq), len(seq)), seq)

    def test_encodeKnownNum(self):
        '''_encode should give known long int with known tuple
        '''
        for t, num in self.knownValuesEncode:
            self.assertEqual(xMANclass._encode(t), num)

    def test_decodeKnownNum(self):
        '''_decode should give tuple with known long int
        '''
        for t, num in self.knownValuesEncode:
            self.assertEqual(xMANclass._decode(num, len(t)), list(t))

    def test_seqnumRCKnowSeq(self):
        '''_seqnumRC should give reverse complement DNA sequence
        '''
        for dna, revdna in self.knownSeq:
            self.assertEqual(xMANclass._seqnumRC(xMANclass._seq2num(dna),lseq=len(dna)),
                             xMANclass._seq2num(revdna))

    def test_ncopy(self):
        '''_ncopy should give number of elements from the know input
        '''
        for ele, ncopy in self.knownElements:
            self.assertEqual(xMANclass._ncopy(ele), ncopy)



class TestxMAN(unittest.TestCase):
    def setUp(self):
        self.seq = ['AAGCTTGTCAAGTAAGCTACCTATT', 'GAAAGGGAGTGTGTGTTGGGAGTTG', 'GACTGCTTGCGTGAAACATTTCTCT', 'AAAACTTAGTCTTGGTTGCCAATCT', 'GACAGTTTGTAAATGAAGGGGAAGA', 'AAATATATAAATTAGCTTTCTAATA', 'AAATGTGAACCAAAGCAGGGAATAA', 'ATGTAAGTAAGTGGGTGTTGGGGAA', 'TTTGAATATCTCAAGTTTTTGCTTT', 'AGTTCTATTTCAAAGTTCTTCAAAA', 'CTGATGTTCCTGCATACTGTGTTCC', 'AATACAAGATGGAAACTGTGAAGTA', 'AGTATGTACCTTCAAAAAAGAAGAA', 'CTTCAAGGAACATTTAGGATAGATT', 'ATTTAGGATATATGAACATGTGGCA', 'GAAAGAACATAATTCTTTCCCAGAA', 'GGGGAGCTATACTTAATCGGATCCA', 'CATCACTGGAAGTCATTTTCTCGCC', 'TATCTCCACGGCAAAATCTGATGGA', 'ATTCTCCGTGCTTTTTGTTTATGTA', 'ATTCATTTTTTGGTAGATAAAGCCT', 'AATGCTATGCAGTAAAACATACCTT', 'TTTAGCATCTTGACTTTGTGTGTGT', 'TTTGTATTTGAGAATACATGTAAAT', 'CAAAAATTATTTAAATTACATACGC', 'AAAAATTTGTTATAGATCTGATTTA', 'CCCCTCCCTTGTTGGGAATTGTAGT', 'AATCTTACATGAAATCATTAGACCA', 'AACAATGGCAGAGGCTACTTTGTGA', 'GAAAAACTGCACTTTCACATCATCA', 'GGTAGACCGTCGAATACATCAATTA', 'TGTCTGTTGTAATGTTATCAAGTAC','AAGCTTGTCAAGTAAGCTACCTATT', 'AATAGGTAGCTTACTTGACAAGCTT', 'CAACTCCCAACACACACTCCCTTTC', 'CAACTCCCAACACAACTCCCTTTAA',
'CAACTCCCccCACAACTCCCTTTAA', 'AGAGAAATGTTTCACGCAAGCAGTC', 'AAGCTTGTCAAGTAAGCTACCTATT']


    def testSearchGenome(self):
        '''SearchGenome OK'''
        seqfile = '../../test/test.fa'

        def SeqIterator():
            for x in self.seq:
                yield x,

        xMANclass = xMANcore.xMAN()
        xMANclass.IndexProbe(SeqIterator())
        xMANclass.SearchGenome([seqfile,])
        self.assertEqual(xMANclass.genome[18593494106040L], 9932144)
        self.assertEqual(xMANclass.genome[269380261298327L],  9928888)
        print '\noriginal mapping..\n'
        xMANclass.PrintOutMatch(sys.stdout)
        xMANclass.PrintOutNOMatch(sys.stdout)
        print xMANclass.MakeSum()
        print '\ndist = 100, maxSeqCopy= 99, oneSeqPerLoc = True, SeqNames = [chr21]\n'
        xMANclass.PrintOutMatch(sys.stdout, dist = 100, maxSeqCopy= 99, oneSeqPerLoc = 1, SeqNames = ['chr21'])
        print xMANclass.MakeSum()





#read program options
if __name__ == '__main__':
    #unittest.main()
    suite = unittest.TestSuite()
    suite.addTests((unittest.makeSuite(TestSeqNum),
                   unittest.makeSuite(TestxMAN)))
    unittest.TextTestRunner(verbosity=2).run(suite)

