#!/usr/bin/env python
# weili@jimmy.harvard.edu


import sys, unittest
from xMAN import *
from numarray import *
filename = '../../test/test.result'
outfile = open(filename,'w', 0)

bp = Myseq(sys.argv[1])

bp.Run(['/home/WeiLi/Database/chr21.fa','/home/WeiLi/Database/chr22.fa'])
bp.PrintOut(outfile)
#bp.PrintOut(open('test.result.chr21','w', 0), dist = 1000, maxSeqCopy= 100, oneSeqPerLoc = True, SeqNames = ['chr21'])
#tp = Mytpmap(filename)
#tp.Makebpmap()

