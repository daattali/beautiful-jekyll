CREATE LOGIN [agent] WITH PASSWORD = 'p@ssword1rocks'
GO