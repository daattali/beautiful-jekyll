grant view any column master key definition to agent
go

grant view any column encryption key definition to agent
go