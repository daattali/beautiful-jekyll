﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsuranceAPI
{
    public partial class InsuranceEntities
    {
        public InsuranceEntities(string connectionString) : base(connectionString)
        {

        }
    }
}